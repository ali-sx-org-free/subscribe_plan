'use strict';
/* Word 寫作規範 Portal：內容來自 content.js（由 scripts/build_portal.py 產生），外殼來自 shell.js（與 01 包相同）。 */
const FMT = GUIDE.format;
const PROF = FMT.profiles[FMT.profile];
const config = {
  title: 'Word 寫作規範', subtitle: 'WORD WRITING KIT', first: 'overview',
  groups: GUIDE.groups.map(g => ({id: g.id, name: g.name, en: g.en,
    pages: g.pages.map(p => ({id: p.id, name: p.name, desc: p.desc}))}))
};
const PAGES = {};
const ORDER = [];
GUIDE.groups.forEach(g => g.pages.forEach(p => { PAGES[p.id] = {...p, group: g}; ORDER.push(p.id); }));

/* ---------- 示意圖 ---------- */
const pt = v => v + ' pt';
const C = FMT.colors;
const previews = {
  stats() {
    const tw = (FMT.page.widthCm - FMT.page.marginLeftCm - FMT.page.marginRightCm).toFixed(1);
    const tiles = [
      ['紙張與版心', FMT.page.size, '版心寬 ' + tw + ' cm'],
      ['正文', pt(FMT.sizePt.body), '固定行高 ' + pt(FMT.lineSpacingPt.body) + '，首行縮排 2 字'],
      ['標題層級', FMT.headings.maxLevel + ' 級', FMT.headings.numbering.join('／')],
      ['自動檢查', '14 項', '另有 10 項人工內容檢查']];
    return '<div class="four-col">' + tiles.map(t => `<section class="panel panel-body stat"><span class="muted">${t[0]}</span><div class="value">${esc(t[1])}</div><small>${esc(t[2])}</small></section>`).join('') + '</div>';
  },
  page() {
    const p = FMT.page;
    const lines = n => Array.from({length: n}, (_, i) => `<div class="ln${i === 0 ? ' ind' : ''}${i === n - 1 ? ' end' : ''}"></div>`).join('');
    return `<div class="pv-two"><div class="pv-paper"><div class="pv-page" role="img" aria-label="A4 版面示意">
      <div class="area"></div><div class="hd">文件名稱</div>
      <div class="h">一、一級標題</div>${lines(5)}<div class="tb"><i></i><i></i><i></i><i></i></div><div class="co"></div>${lines(4)}
      <div class="ft">— 1 —</div></div></div>
      <dl class="spec-list">
        <dt>紙張</dt><dd>${p.size} 直式 ${p.widthCm} × ${p.heightCm} cm</dd>
        <dt>上／下邊界</dt><dd>${p.marginTopCm} cm／${p.marginBottomCm} cm</dd>
        <dt>左／右邊界</dt><dd>${p.marginLeftCm} cm／${p.marginRightCm} cm（虛線為版心）</dd>
        <dt>頁首</dt><dd>距頁緣 ${p.headerCm} cm；文件名稱 ${pt(FMT.sizePt.header)} 灰字＋細線</dd>
        <dt>頁碼</dt><dd>距頁緣 ${p.footerCm} cm；「${esc(p.pageNumberFormat.replace('{n}', '1'))}」自正文起編</dd>
        <dt>正文字型</dt><dd>${esc(PROF.fonts.body)}＋${esc(PROF.fonts.latin)}</dd>
        <dt>標題字型</dt><dd>${esc(PROF.fonts.heading)}</dd>
        <dt>引文字型</dt><dd>${esc(PROF.fonts.quote)}</dd></dl></div>`;
  },
  headings() {
    const s = FMT.sizePt, l = FMT.lineSpacingPt;
    const row = (sample, note) => `${sample}<div class="note">${note}</div>`;
    return `<div class="pv-doc pv-ann">
      ${row('<div class="pv-h1">一、背景</div>', `標題 1 · ${pt(s.h1)} 墨藍 · 行高 ${pt(l.h1)}`)}
      ${row('<div class="pv-h2">（一）現況</div>', `標題 2 · ${pt(s.h2)} · 行高 ${pt(l.h2)}`)}
      ${row('<div class="pv-h3">1. 資料來源</div>', `標題 3 · ${pt(s.h3)} 粗體`)}
      ${row('<p class="pv-body"><b>結論先寫：</b>正文首行縮排兩字，兩端對齊，段落之間不留空行。</p>', `內文 · ${pt(s.body)} · 固定行高 ${pt(l.body)}`)}
      ${row('<p class="pv-body list">（1）正文中的列舉一律用括號數字。</p>', '列舉用（1），不用 1.')}
      ${row('<div class="pv-quote">引文與說明使用楷體，左縮排兩字。</div>', `引文 · ${esc(PROF.fonts.quote)}`)}</div>`;
  },
  table() {
    return `<div class="pv-doc"><div class="pv-cap">${esc(PROF.labels.table)} 1　各團隊統計週期</div>
      <table class="pv-3line"><thead><tr><th>團隊</th><th>週期</th><th>樣本數</th><th>能否改為按日</th></tr></thead>
      <tbody><tr><td>甲</td><td>按日</td><td class="num">15,000</td><td>已是</td></tr>
      <tr><td>乙</td><td>按週</td><td class="num">8,420</td><td>可，約需 1 週</td></tr>
      <tr><td>丙</td><td>按月</td><td class="num">1,260</td><td><b class="sans">需兩週改造</b></td></tr></tbody></table>
      <div class="pv-src">資料來源：素材索引 B-02，截至 2026-09-30。</div></div>
      <p class="muted" style="font-size:12px;margin-top:6px">頂線、底線 ${FMT.table.outerRulePt} pt，表頭下線 ${FMT.table.headerRulePt} pt；無直線；數值靠右；表題在上、資料來源在下。</p>`;
  },
  code() {
    const t = FMT.code.themes[FMT.code.theme];
    const s = (c, x) => `<span style="color:#${t[c]}">${esc(x)}</span>`;
    const body = [s('comment', '# 交付設定'), s('key', 'delivery') + s('default', ':'),
      s('default', '  ') + s('key', 'period') + s('default', ': ') + s('string', '"daily"') + s('default', '   ') + s('comment', '# 按日彙總'),
      s('default', '  ') + s('key', 'maxMissingRate') + s('default', ': ') + s('number', '0.01'),
      s('default', '  ') + s('key', 'owner') + s('default', ': ') + s('variable', '${TEAM}')].join('\n');
    return `<div class="pv-code" style="background:#${t.background}">${body}</div>`;
  },
  colors() {
    const sw = [['正文', C.text], ['題名、一級標題', C.title], ['輔助文字', C.aux], ['頁首', C.header], ['線條', C.line], ['底紋', C.shade]];
    return '<div class="swatches">' + sw.map(([n, c]) => `<div class="swatch"><i style="background:#${c}${c === 'F2F2F2' ? ';border-bottom:1px solid var(--line)' : ''}"></i><strong>${n}</strong><code>#${c}</code></div>`).join('') + '</div>';
  },
  callout() {
    return `<div class="pv-doc"><div class="pv-callout"><b>${esc(PROF.labels.callout)}：</b>交付數據自 2027 年 1 月起一律按日彙總，不符者退回。</div>
      <p class="pv-body"><b>原因：</b>三個團隊的統計週期不同，週報無法合併；按日彙總是三方都已具備的能力。</p></div>`;
  },
  emphasis() {
    return `<div class="pv-dodont"><div class="pv-doc"><h4><span class="badge green">使用</span>三種強調</h4>
      <div class="pv-callout"><b>要點：</b>每章最多一個。</div>
      <p class="pv-body"><b>粗體引導句：</b>每段最多一處。</p>
      <p class="pv-body">並列比較與數字：改用表格。</p></div>
      <div class="pv-doc bad"><h4><span class="badge red">不用</span>黑白列印會失效或稀釋重點</h4>
      <span style="color:#c00">紅字強調</span><span style="text-decoration:underline">底線</span><span style="font-style:italic">斜體</span>
      <span style="background:#fff200">螢光標記</span><span style="font-weight:700">整段加粗整段加粗整段加粗</span><span>‼️ 表情符號</span></div></div>`;
  },
  flow() {
    const steps = [['確認 Word 已關閉'], ['比對使用者手改', 1], ['複製新版本號'], ['就地編輯'], ['finish.py 收尾', 1], ['回報']];
    return '<div class="pv-steps">' + steps.map((s, i) => `<span class="${s[1] ? 'key' : ''}"><b>${i + 1}</b>${s[0]}</span>`).join('<i>→</i>') + '</div>';
  },
  chapter() {
    const rows = [['① 結論', '本章的答案，一到三句；重要的放進要點框', 'first'], ['② 理由與依據', '為什麼是這個結論，引用哪些素材'],
      ['③ 細節', '條款、表格、步驟、例外情況'], ['④ 待確認', '標「待拍板」，寫明誰決定什麼']];
    return '<div class="pv-chapter">' + rows.map(r => `<div class="${r[2] || ''}"><span>${r[0]}</span><span>${r[1]}</span></div>`).join('') + '</div>';
  }
};

/* ---------- 互動元件 ---------- */
function copyText(text) {
  const done = () => toast('已複製到剪貼簿');
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(text).then(done, () => fallback());
  } else fallback();
  function fallback() {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); done(); } catch { toast('無法自動複製，請手動選取文字。'); }
    ta.remove();
  }
}

function hydrate(root, page) {
  root.querySelectorAll('.preview').forEach(el => {
    const f = previews[el.dataset.preview];
    if (f) el.innerHTML = f(); else el.remove();
  });
  root.querySelectorAll('pre.copyable').forEach(pre => {
    const wrap = document.createElement('div');
    wrap.className = 'code-wrap';
    pre.replaceWith(wrap); wrap.appendChild(pre);
    const b = document.createElement('button');
    b.className = 'button copy-btn'; b.type = 'button'; b.textContent = '複製';
    b.onclick = () => copyText(pre.textContent);
    wrap.appendChild(b);
  });
  root.querySelectorAll('[data-checklist]').forEach((box, bi) => {
    const key = 'w2-check-' + page.id + '-' + bi;
    const saved = storeRead(key, []);
    const inputs = [...box.querySelectorAll('input')];
    const head = document.createElement('div');
    head.className = 'check-head';
    head.innerHTML = '<span class="count"></span><div class="progress"><i></i></div><button class="text-btn" type="button">清除勾選</button>';
    box.before(head);
    const update = () => {
      const n = inputs.filter(i => i.checked).length;
      head.querySelector('.count').textContent = `已確認 ${n} / ${inputs.length}`;
      head.querySelector('.progress i').style.width = (inputs.length ? n / inputs.length * 100 : 0) + '%';
    };
    inputs.forEach((inp, i) => {
      inp.checked = saved.includes(i);
      inp.onchange = () => { storeWrite(key, inputs.map((x, k) => x.checked ? k : -1).filter(k => k >= 0)); update(); };
    });
    head.querySelector('button').onclick = () => { inputs.forEach(x => x.checked = false); storeWrite(key, []); update(); };
    update();
  });
}

/* ---------- 搜尋 ---------- */
let INDEX = null;
function buildIndex() {
  const div = document.createElement('div');
  INDEX = ORDER.map(id => {
    const p = PAGES[id];
    div.innerHTML = p.html;
    return {id, name: p.name, group: p.group.name, text: (p.name + ' ' + p.desc + ' ' + div.textContent).replace(/\s+/g, ' ')};
  });
}
function openSearch() {
  if (!INDEX) buildIndex();
  modal('搜尋指引', '<label>關鍵字 <input id="q" type="search" placeholder="例：三線表、鎖定檔、表〔表題〕、renumber" autocomplete="off"></label><div class="search-results" id="results"><p class="muted">輸入關鍵字，搜尋全部 ' + ORDER.length + ' 頁。</p></div>');
  const q = $('#q');
  q.oninput = () => {
    const v = q.value.trim().toLowerCase();
    const box = $('#results');
    if (!v) { box.innerHTML = '<p class="muted">輸入關鍵字，搜尋全部 ' + ORDER.length + ' 頁。</p>'; return; }
    const hits = INDEX.map(r => ({r, at: r.text.toLowerCase().indexOf(v)})).filter(h => h.at >= 0).slice(0, 12);
    box.innerHTML = hits.length ? hits.map(({r, at}) => {
      const a = Math.max(0, at - 24), snip = r.text.slice(a, at + v.length + 40);
      const k = snip.toLowerCase().indexOf(v);
      const mk = esc(snip.slice(0, k)) + '<mark>' + esc(snip.slice(k, k + v.length)) + '</mark>' + esc(snip.slice(k + v.length));
      return `<a href="#${r.id}"><strong>${esc(r.name)}</strong><small>${esc(r.group)}</small>${a ? '…' : ''}${mk}…</a>`;
    }).join('') : '<p class="muted">沒有符合的內容。</p>';
    box.querySelectorAll('a').forEach(x => x.onclick = () => $('#dialog').close());
  };
  setTimeout(() => q.focus(), 30);
}

/* ---------- 頁面 ---------- */
function render() {
  const route = shell(config);
  const page = PAGES[route];
  $('#page-actions').innerHTML = '<button class="button" id="open-search" title="快捷鍵 /">搜尋指引 <kbd>/</kbd></button><a class="button" href="' + esc(page.src) + '">Markdown 原文</a>';
  $('#open-search').onclick = openSearch;
  const i = ORDER.indexOf(route);
  const prev = PAGES[ORDER[i - 1]], next = PAGES[ORDER[i + 1]];
  const pager = '<nav class="pager" aria-label="上一頁與下一頁">' +
    (prev ? `<a class="prev" href="#${prev.id}"><small>‹ 上一頁 · ${esc(prev.group.name)}</small>${esc(prev.name)}</a>` : '') +
    (next ? `<a class="next" href="#${next.id}"><small>下一頁 · ${esc(next.group.name)} ›</small>${esc(next.name)}</a>` : '') + '</nav>';
  $('#content').innerHTML = `<div class="doc-layout"><div><article class="panel panel-body prose doc" id="doc">${page.html}</article>${pager}</div><aside class="rail" id="rail"></aside></div>`;
  const doc = $('#doc');
  hydrate(doc, page);
  const heads = [...doc.querySelectorAll('h2')];
  heads.forEach((h, k) => h.id = 'sec-' + k);
  $('#rail').innerHTML = `<section class="panel panel-body"><h2>本頁段落</h2>${heads.length ? heads.map((h, k) => `<a href="#${route}" data-sec="${k}">${esc(h.textContent)}</a>`).join('') : '<span class="muted" style="font-size:12px">本頁沒有分段。</span>'}<div class="src">原文：${esc(page.src)}<br>改內容請編輯原文，再執行 scripts/build_portal.py。</div></section>`;
  $('#rail').querySelectorAll('[data-sec]').forEach(a => a.onclick = e => { e.preventDefault(); heads[+a.dataset.sec].scrollIntoView({behavior: 'smooth', block: 'start'}); });
  window.scrollTo(0, 0);
}

document.addEventListener('keydown', e => {
  if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) && !$('#dialog').open) {
    e.preventDefault(); openSearch();
  }
});
window.addEventListener('hashchange', render);
render();
