# -*- coding: utf-8 -*-
"""把 docx 匯出為文字快照，用於版本間比對，找出使用者在 Word 裡的手改。

用法：
  python docx_dump.py 文件.docx                    # 印出快照
  python docx_dump.py 文件.docx 快照.txt           # 存成檔案
  python docx_dump.py 文件.docx --diff 上一版.txt  # 與上一版快照（或 .docx）比對

快照標記：
  [H1]/[H2]/[H3] 標題   [P ] 正文   [LI] 清單   [Q ] 引文   [!] 要點框
  [CAP] 題注   [SRC] 資料來源   [CODE] 程式碼   [TOC] 目錄（內容略）
  [MEDIA] 圖片（含尺寸）——必須保留，否則刪掉圖片時比對不出來
  [TABLE r×c] … [/TABLE] 表格   [§] 分節   [COMMENT] Word 註解
"""
from __future__ import annotations

import argparse
import difflib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import docxkit as K  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402
from docx.text.paragraph import Paragraph  # noqa: E402

WP = "{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}"


def _media(p_el):
    tags = []
    for t, label in ((qn("w:drawing"), "IMG"), (qn("w:pict"), "PICT"), (qn("w:object"), "OBJ")):
        for e in p_el.iter(t):
            ext = e.find(".//" + WP + "extent")
            if ext is not None:
                tags.append("%s %.1f×%.1fcm" % (label, int(ext.get("cx", 0)) / 360000,
                                                int(ext.get("cy", 0)) / 360000))
            else:
                tags.append(label)
    return tags


def _tag(style_name):
    key = K.style_key(style_name)
    low = (style_name or "").lower()
    if key in ("h1", "h2", "h3"):
        return "[H%s]" % key[1]
    if low.startswith("heading"):
        return "[H%s]" % low.split()[-1]
    return {"quote": "[Q ]", "callout": "[! ]", "caption": "[CAP]", "source": "[SRC]",
            "code": "[CODE]", "title": "[TITLE]", "subtitle": "[SUB]", "meta": "[META]",
            "tocTitle": "[TOC-TITLE]"}.get(key, "[LI]" if "list" in low else "[P ]")


def dump(path):
    doc = K.open_document(path, quiet=True)
    span = K.find_toc_span(doc)
    in_toc = set()
    if span:
        a, b = span
        cur = a
        while cur is not None:
            in_toc.add(cur)
            if cur is b:
                break
            cur = cur.getnext()
    out, toc_done = [], False
    for blk in K.iter_blocks(doc):
        if isinstance(blk, Paragraph):
            p = blk._p
            if p in in_toc:
                if not toc_done:
                    out.append("[TOC]（目錄功能變數，內容略）")
                    toc_done = True
                continue
            media = _media(p)
            if media:
                out.append("[MEDIA] " + " | ".join(media))
            txt = K.ptext(p).replace("\xa0", " ").rstrip()
            if txt.strip():
                tag = _tag(blk.style.name)
                out.append("%s %s" % (tag, txt if tag == "[CODE]" else txt.strip()))
            if p.find(qn("w:pPr") + "/" + qn("w:sectPr")) is not None:
                out.append("[§] 分節")
        else:
            rows = blk.rows
            out.append("[TABLE %d×%d]" % (len(rows), len(blk.columns)))
            for row in rows:
                cells, seen = [], set()
                for c in row.cells:
                    if id(c._tc) in seen:
                        continue
                    seen.add(id(c._tc))
                    t = " / ".join(K.ptext(p._p).strip() for p in c.paragraphs)
                    m = [x for p in c.paragraphs for x in _media(p._p)]
                    cells.append(t + ((" [MEDIA " + ",".join(m) + "]") if m else ""))
                out.append("  | " + " | ".join(cells))
            out.append("[/TABLE]")
    comments = K.read_comments(doc)
    if comments:
        out.append("")
        for cid, author, text, anchor in comments:
            out.append("[COMMENT #%s %s] %s ← 錨定段落：「%s」" % (cid, author, text, anchor[:30]))
    ins, dele = K.tracked_changes(doc)
    if ins or dele:
        out.append("[!] 文件含修訂標記：插入 %d、刪除 %d（快照以接受修訂後的文字呈現）" % (ins, dele))
    return "\n".join(out) + "\n"


def main():
    ap = argparse.ArgumentParser(description="docx → 文字快照／比對")
    ap.add_argument("docx")
    ap.add_argument("out", nargs="?")
    ap.add_argument("--diff", help="上一版快照 .txt 或 .docx")
    a = ap.parse_args()
    lk = K.lock_file(a.docx)
    if lk:
        print("【注意】%s 存在：Word 可能仍開著此檔。" % lk.name, file=sys.stderr)
    text = dump(a.docx)
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(text, encoding="utf-8")
        print("快照已寫入 %s（%d 行）" % (a.out, text.count("\n")))
    if a.diff:
        old = dump(a.diff) if a.diff.lower().endswith(".docx") else \
            Path(a.diff).read_text(encoding="utf-8")
        diff = list(difflib.unified_diff(old.splitlines(), text.splitlines(),
                                         a.diff, a.docx, lineterm="", n=1))
        print("\n".join(diff) if diff else "與 %s 無差異。" % a.diff)
    elif not a.out:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()
