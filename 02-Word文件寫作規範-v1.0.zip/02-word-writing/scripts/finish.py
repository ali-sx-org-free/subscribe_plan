# -*- coding: utf-8 -*-
"""每輪收尾：一個指令依固定順序完成，避免漏步驟或順序錯。

  0. Word 鎖定檔檢查（使用者仍開著檔案時停止，否則其後存檔會覆蓋本輪結果）
  1. 字型歸一＋圖片段落行距修正      （normalize_fonts）
  2. 表題、圖題重新編號＋同步正文引用  （docxkit.renumber）
  3. 重建目錄功能變數                  （reset_toc；文件無目錄時略過）
  4. 存檔 → 排版檢查                   （check_doc）
  5. 存快照 snapshots/<檔名>.txt       （docx_dump；下一輪用來比對使用者手改）

用法：python finish.py 文件_v0.21.docx [--release] [--snapshots 資料夾] [--ignore-lock]
離開碼：檢查全部通過為 0，有未通過項為 1，被鎖定檔擋下為 2。
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_doc  # noqa: E402
import docx_dump  # noqa: E402
import docxkit as K  # noqa: E402
import normalize_fonts  # noqa: E402
import reset_toc  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description="每輪收尾")
    ap.add_argument("docx")
    ap.add_argument("--release", action="store_true", help="發佈模式檢查")
    ap.add_argument("--snapshots", help="快照資料夾（預設為文件旁的 snapshots/）")
    ap.add_argument("--ignore-lock", action="store_true", help="確認使用者已關閉 Word 時才使用")
    a = ap.parse_args()
    path = Path(a.docx)

    lk = K.lock_file(path)
    if lk and not a.ignore_lock:
        print("停止：%s 存在，使用者可能仍在 Word 開著此檔。請對方關閉後再執行。" % lk.name)
        sys.exit(2)

    doc = K.open_document(path)
    st, unknown = normalize_fonts.normalize(doc)
    print("1 字型歸一：" + ("、".join("%s %d 處" % kv for kv in st.items()) if st else "無需修改"))
    if unknown:
        print("  【待確認】不在規範內的中文字型：" + "、".join("%s（%d）" % kv for kv in unknown.items()))
    r = K.renumber(doc)
    remap = {k: v for k, v in r["remap"].items() if v}
    print("2 圖表編號：表 %d、圖 %d%s" % (r["tables"], r["figures"],
                                     "；號碼變動 %s" % remap if remap else ""))
    for before, after in r["refs"]:
        print("  引用已同步：「%s」→「%s」" % (before, after))
    for u in r["unresolved"]:
        print("  【待處理】找不到對應題注的引用：%s" % u)
    t = reset_toc.reset(doc)
    print("3 目錄：" + ("已重建，Word 開檔時自動更新" if t else "文件無目錄，略過"))
    doc.save(str(path))

    rep = check_doc.run_checks(path, a.release)
    print()
    print(check_doc.render(rep, path))

    snap_dir = Path(a.snapshots) if a.snapshots else path.parent / "snapshots"
    snap_dir.mkdir(parents=True, exist_ok=True)
    snap = snap_dir / (path.stem + ".txt")
    snap.write_text(docx_dump.dump(path), encoding="utf-8")
    print("\n5 快照：%s（下一輪開工時用它比對使用者手改）" % snap)
    sys.exit(0 if all(i["status"] != "fail" for i in rep.items) else 1)


if __name__ == "__main__":
    main()
