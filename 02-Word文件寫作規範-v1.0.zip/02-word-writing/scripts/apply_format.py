# -*- coding: utf-8 -*-
"""把 format.json 的版式套到一份既有文件（例如使用者帶來、非本工具建立的文件）。

只改「樣式、預設字型、佈景主題字型、頁面設定」，不改任何文字內容。
因為不是逐段直接格式，使用者在 Word 中手動加的直接格式仍會保留；
套用後請跑 finish.py 檢查，再與使用者確認差異。

用法：python apply_format.py 原檔.docx 新檔.docx
（一律輸出到新檔，不覆蓋原檔。）
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import docxkit as K  # noqa: E402
import normalize_fonts  # noqa: E402


def main():
    if len(sys.argv) != 3 or Path(sys.argv[1]).resolve() == Path(sys.argv[2]).resolve():
        print(__doc__)
        sys.exit(2)
    doc = K.open_document(sys.argv[1])
    K.apply_format(doc)
    st, unknown = normalize_fonts.normalize(doc)
    doc.save(sys.argv[2])
    print("已套用版式（%s）→ %s" % (K.F.profile, sys.argv[2]))
    if st:
        print("字型歸一：" + "、".join("%s %d 處" % kv for kv in st.items()))
    if unknown:
        print("【待確認】不在規範內的中文字型：" + "、".join("%s（%d）" % kv for kv in unknown.items()))


if __name__ == "__main__":
    main()
