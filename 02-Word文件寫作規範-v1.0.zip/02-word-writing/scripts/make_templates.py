# -*- coding: utf-8 -*-
"""產生 templates/ 下的兩份 Word 檔，同時是 docxkit 的完整用法範例。

  空白範本.docx  ：封面＋目錄＋正文節的起始版型，人可直接在 Word 裡填寫。
  範例文件.docx  ：示範全部版面元素；內容就是本規範的摘要，可列印查閱。

用法：python make_templates.py [輸出資料夾]   （預設為套件的 templates/）
示意圖需要 Pillow（pip install pillow）；沒有時略過圖片。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import docxkit as K  # noqa: E402

OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else K.ROOT / "templates"


def page_diagram(path):
    """畫一張 A4 版面示意圖（中性內容）。"""
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        return None
    fonts = ["/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
             "C:/Windows/Fonts/msjh.ttc", "/System/Library/Fonts/PingFang.ttc"]
    font = next((p for p in fonts if Path(p).exists()), None)
    S = 4
    W, H = 900 * S // 2, 620 * S // 2

    def F(sz):
        return ImageFont.truetype(font, sz * S // 2) if font else ImageFont.load_default()
    im = Image.new("RGB", (W, H), "white")
    d = ImageDraw.Draw(im)
    s = S // 2
    px, py, pw, ph = 250 * s, 30 * s, 400 * s, 560 * s           # A4 頁面（21×29.7 縮放）
    k = pw / 21.0
    d.rectangle([px, py, px + pw, py + ph], outline=(0x59, 0x59, 0x59), width=2 * s)
    l, r, t, b = 2.5 * k, 2.5 * k, 2.2 * k, 2.2 * k
    gray, ink, line = (0x99, 0x99, 0x99), (0x1F, 0x38, 0x64), (0xBF, 0xBF, 0xBF)
    d.rectangle([px + l, py + t, px + pw - r, py + ph - b], outline=line, width=s)
    hy = py + 1.2 * k + 10 * s
    d.text((px + pw / 2, py + 1.2 * k), "文件名稱", fill=gray, font=F(11), anchor="mt")
    d.line([px + l, hy + 6 * s, px + pw - r, hy + 6 * s], fill=line, width=s)
    d.text((px + pw / 2, py + ph - 1.4 * k), "— 1 —", fill=gray, font=F(11), anchor="mb")
    y = py + t + 14 * s
    d.text((px + l, y), "一、一級標題", fill=ink, font=F(15))
    y += 30 * s
    for i in range(9):
        x0 = px + l + (22 * s if i in (0, 5) else 0)
        x1 = px + pw - r - (60 * s if i in (4, 8) else 0)
        d.line([x0, y, x1, y], fill=(0x30, 0x30, 0x30), width=3 * s)
        y += 15 * s
    y += 8 * s
    d.text((px + pw / 2, y), "表 1　表題", fill=(0, 0, 0), font=F(10), anchor="mt")
    y += 20 * s
    d.line([px + l + 20 * s, y, px + pw - r - 20 * s, y], fill=(0, 0, 0), width=3 * s)
    d.line([px + l + 20 * s, y + 18 * s, px + pw - r - 20 * s, y + 18 * s], fill=(0, 0, 0), width=s)
    for j in range(3):
        d.line([px + l + 30 * s, y + (32 + j * 14) * s, px + pw - r - 30 * s, y + (32 + j * 14) * s],
               fill=(0xC8, 0xC8, 0xC8), width=2 * s)
    d.line([px + l + 20 * s, y + 76 * s, px + pw - r - 20 * s, y + 76 * s], fill=(0, 0, 0), width=3 * s)
    y += 96 * s
    d.rectangle([px + l, y, px + pw - r, y + 46 * s], fill=(0xF2, 0xF2, 0xF2))
    d.rectangle([px + l, y, px + l + 4 * s, y + 46 * s], fill=ink)
    d.text((px + l + 14 * s, y + 14 * s), "要點：本章結論", fill=(0, 0, 0), font=F(11))

    def label(x0, y0, x1, y1, txt, side):
        d.line([x0, y0, x1, y1], fill=ink, width=s)
        if side == "l":
            d.text((x0 - 8 * s, (y0 + y1) / 2), txt, fill=ink, font=F(12), anchor="rm")
        else:
            d.text((x1 + 8 * s, (y0 + y1) / 2), txt, fill=ink, font=F(12), anchor="lm")
    label(px - 20 * s, py, px - 20 * s, py + t, "上邊界 2.2 cm", "l")
    label(px - 20 * s, py + ph - b, px - 20 * s, py + ph, "下邊界 2.2 cm", "l")
    d.line([px, py + ph + 14 * s, px + l, py + ph + 14 * s], fill=ink, width=s)
    d.text((px + l / 2, py + ph + 18 * s), "左 2.5", fill=ink, font=F(11), anchor="mt")
    d.line([px + pw - r, py + ph + 14 * s, px + pw, py + ph + 14 * s], fill=ink, width=s)
    d.text((px + pw - r / 2, py + ph + 18 * s), "右 2.5", fill=ink, font=F(11), anchor="mt")
    notes = [("頁首：文件名稱，7.5 pt 灰字＋細線", py + 1.2 * k + 6 * s),
             ("一級標題：標題字型 15 pt 墨藍", py + t + 22 * s),
             ("正文：10.5 pt，固定行高 18 pt，首行縮排 2 字", py + t + 90 * s),
             ("三線表：頂底 1.5 pt、表頭線 0.75 pt", py + t + 220 * s),
             ("要點框：淺灰底＋左側墨藍線", py + t + 300 * s),
             ("頁碼：— 1 —，正文首頁起編", py + ph - 1.4 * k - 8 * s)]
    for txt, yy in notes:
        d.line([px + pw + 6 * s, yy, px + pw + 26 * s, yy], fill=line, width=s)
        d.text((px + pw + 32 * s, yy), txt, fill=(0x30, 0x30, 0x30), font=F(12), anchor="lm")
    im = im.resize((W // 2, H // 2), Image.LANCZOS)
    im.save(path)
    return path


def blank(path):
    doc = K.new_document()
    w = K.Writer(doc)
    w.title("〔文件題名〕", sub="〔副題：一句話說明本文件解決什麼問題〕",
            meta=["版本 v0.1　討論稿", "〔撰寫單位〕　〔日期〕"])
    w.toc()
    w.body_section("〔文件題名〕")
    w.h1("一、背景")
    w.callout("〔用一到兩句寫出本文件的結論或核心要求。〕")
    w.p("〔正文。每段只講一件事；第一句先寫結論，再寫理由與依據。〕")
    w.h1("二、〔章名〕")
    w.h2("（一）〔節名〕")
    w.p("〔正文。〕")
    doc.save(str(path))


def example(path, img):
    doc = K.new_document()
    w = K.Writer(doc)
    w.title("正式文件寫作要點", sub="範例文件——示範本規範的全部版面元素",
            meta=["版本 v1.0　範例", "Word 文件寫作規範　2026-10"])
    w.toc()
    w.body_section("正式文件寫作要點")

    w.h1("一、文件用途")
    w.callout("本文件示範規範中的每一種版面元素，內容即寫作規範的摘要，可列印後隨手查閱。")
    w.p("本規範適用於需要對外發送、存檔或提交審閱的正式文件，包括規範、方案、白皮書與"
        "匯報材料。文件由人與 agent 多輪協作完成，使用者會在兩輪之間直接用 Word 修改同一份檔案。")
    w.p("文件好不好讀，取決於三件事：讀者能否在一分鐘內找到結論，條款能否被客觀判定，"
        "版面能否讓層次一眼可辨。以下各章分別說明。")

    w.h1("二、寫作原則")
    w.h2("（一）結論先行")
    w.lead("每章第一段先寫結論。", "讀者只讀各章標題與首段，也應能掌握全文主張；"
           "理由、依據與細節放在後面，供需要的人查閱。")
    w.p("標題也是結論的一部分。方案與匯報類文件的標題宜直接寫出判斷，例如「三、資料口徑統一"
        "為按日彙總」，比「三、資料口徑」更有資訊量；規範類文件的標題則維持中性名詞。")
    w.h2("（二）寫可判定的條款")
    w.p("條款要能被第三人客觀判定是否做到。「應當盡量及時更新」無法判定；「應於每週五 18:00 前"
        "更新，逾期未更新則該週數據不予採用」才是條款。用語強度見表〔條款用語強度〕。")
    w.table("條款用語強度", ["用語", "強度", "含義", "例句"], [
        ["**應**", "強制", "必須做到，否則不符合本規範", "表格應採用三線表。"],
        ["**不得**", "禁止", "做了即不符合本規範", "正文不得以空行調整間距。"],
        ["**宜**", "建議", "推薦做法，偏離時須說明理由", "每段宜不超過 250 字。"],
        ["**可**", "允許", "可以做，也可以不做", "附錄可放原始資料。"],
    ], widths_cm=[2.2, 1.8, 5.0, 7.0], source="資料來源：參照標準化文件的用語慣例整理。")
    w.h2("（三）重點突出")
    w.p("強調手段越少越有效。本規範只保留三種：")
    w.item("（1）要點框：一章最多一個，放本章結論或必讀要求；")
    w.item("（2）粗體引導句：段首一句加粗，概括該段，每段最多一處；")
    w.item("（3）表格：三項以上並列比較、或含數字時，改用表格呈現。")
    w.p("不使用顏色、底線、斜體、螢光標記或整段加粗來強調；這些在黑白列印時會失效，"
        "用多了反而沒有重點。")

    w.h1("三、版面規範")
    w.h2("（一）頁面與字型")
    f = K.F
    w.p("紙張 A4 直式，版心寬 %.1f cm。字型與字級見表〔字型與字級〕，全部數值由 format.json 統一定義。" % f.text_width_cm)
    w.table("字型與字級", ["元素", "字型", "字級", "行距"], [
        ["文件題名", f.fonts["heading"], "%g pt" % f.size["title"], "固定 %g pt" % f.line["title"]],
        ["一級標題", f.fonts["heading"], "%g pt" % f.size["h1"], "固定 %g pt" % f.line["h1"]],
        ["二級標題", f.fonts["heading"], "%g pt" % f.size["h2"], "固定 %g pt" % f.line["h2"]],
        ["三級標題", f.fonts["heading"] + "（粗體）", "%g pt" % f.size["h3"], "固定 %g pt" % f.line["h3"]],
        ["正文", f.fonts["body"], "%g pt" % f.size["body"], "固定 %g pt" % f.line["body"]],
        ["引文", f.fonts["quote"], "%g pt" % f.size["body"], "固定 %g pt" % f.line["body"]],
        ["表格、題注", f.fonts["body"] + "／" + f.fonts["heading"], "%g pt" % f.size["table"],
         "固定 %g pt" % f.line["table"]],
        ["西文與數字", f.fonts["latin"], "隨所在段落", "—"],
    ], widths_cm=[3.2, 5.0, 3.0, 4.8])
    w.h2("（二）表格與圖")
    w.p("表題在表格上方、圖題在圖片下方，編號依出現順序連續。表格一律為三線表，"
        "標題列跨頁重複；數值靠右對齊，文字靠左對齊。圖片段落一律單行間距，"
        "固定行高會把圖片裁成一條線。版面整體配置如圖〔版面配置示意〕。")
    if img:
        w.figure(img, "版面配置示意", width_cm=15)
    w.note("說明：本圖為示意，實際尺寸以 format.json 為準。換格式要求時只改 format.json，"
           "不改程式碼。")
    w.h2("（三）程式碼")
    w.p("技術文件中的設定檔、指令或資料結構以程式碼區塊呈現：淺灰底、等寬字型、語法著色，"
        "黑白列印仍可閱讀。")
    w.code("# 每輪收尾指令（依序完成：字型歸一、編號、目錄、檢查、快照）\n"
           "python scripts/finish.py 方案_v0.21.docx\n\n"
           "# 發佈前以發佈模式複查\n"
           "python scripts/check_doc.py 方案_v1.0.docx --release", lang="bash")
    w.p("設定檔範例如下，鍵、字串、數值與註解以不同顏色區分：")
    w.code("page:\n  size: A4          # 紙張\n  marginLeftCm: 2.5\n"
           "fonts:\n  body: \"%s\"\n  heading: \"%s\"" % (f.fonts["body"], f.fonts["heading"]), lang="yaml")

    w.h1("四、協作流程")
    w.h2("（一）每輪開工")
    w.h3("1. 先讀出使用者改了什麼")
    w.p("每輪開始前，把使用者交回的最新檔匯出快照，與上一輪的快照比對，逐條列出使用者的修改；"
        "本輪的編輯不得覆蓋這些修改。Word 註解是使用者給 agent 的指示，須逐條處理並回覆。")
    w.h3("2. 在副本上就地編輯")
    w.p("複製出新版本號的檔案，在副本上修改；不得重新產生整份文件。版本號只增不減："
        "v0.x 討論稿、v1.0 生效、v1.x 修訂、v2.0 重構。")
    w.h2("（二）每輪收尾")
    w.p("一律執行收尾指令，依固定順序完成字型歸一、圖表重新編號、目錄重建、排版檢查與存快照。"
        "檢查未通過時，先定位到段落，再判斷問題出自工具還是使用者手填的內容。")
    w.note("「對外文件不是會議記錄。」不引述發言、不出現人名、不平鋪原始素材；以規範制定者的口吻，"
           "把觀點提煉成可判定的條款。")

    w.h1("五、素材與衝突")
    w.p("起草前先把素材分級，級別決定內容能否寫成強制條款；不同素材互相矛盾時，列成表格交由"
        "使用者裁決，不得自行挑一個。分級見表〔素材分級與取用方式〕。")
    w.table("素材分級與取用方式", ["級別", "類型", "取用方式"], [
        ["A 指令", "主管明確要求、已定稿的框架", "可直接寫成強制條款"],
        ["B 實況", "會議紀錄、訪談原文", "還原共識與未決點，轉寫為規範語言"],
        ["C 指導", "方法論文件、討論稿", "作為推導依據，註明其本身未定稿"],
        ["D 參考", "其他團隊的實作方案", "只作落地參考，不得升格為強制規範"],
    ], widths_cm=[2.4, 6.0, 7.6])
    doc.save(str(path))


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    tmp = OUT / "_page.png"
    img = page_diagram(tmp)
    blank(OUT / "空白範本.docx")
    example(OUT / "範例文件.docx", img)
    if img:
        tmp.unlink()
    for name in ("空白範本.docx", "範例文件.docx"):
        p = OUT / name
        doc = K.open_document(p, quiet=True)
        K.renumber(doc)
        doc.save(str(p))
        print("已產生", p)


if __name__ == "__main__":
    main()
