# -*- coding: utf-8 -*-
"""字型歸一：把 Word 存檔、貼上內容帶入的字型別名換回規範字型，並修正圖片段落行距。

處理範圍：正文、樣式、頁首頁尾。
  · 主題字型屬性（asciiTheme、eastAsiaTheme…）一律移除——它們會蓋過明確字型，
    是「新打的字變 Cambria／標題不是黑體」的根因。
  · 中文字型依 format.json 的 fontRoles 換成同角色的規範字型
    （例：PMingLiU→新細明體、微軟雅黑→標題字型、KaiTi→引文字型）。
  · 西文字型一律換成規範西文字型；程式碼段落與等寬字型換成規範程式碼字型。
  · 含圖片的段落若是「固定行高」，圖片會被裁成一條線，改為單行間距。
  · 不認得的中文字型只回報、不更改（加 --force 才換成正文字型）。

用法：python normalize_fonts.py 文件.docx [--force]
"""
from __future__ import annotations

import argparse
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import docxkit as K  # noqa: E402
from docx.enum.text import WD_LINE_SPACING  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402
from docx.text.paragraph import Paragraph  # noqa: E402


def _parts(doc):
    yield doc.part.element, "document"
    yield doc.styles.element, "styles"
    for rel in doc.part.rels.values():
        if rel.is_external:
            continue
        if rel.reltype.endswith(("/header", "/footer")) and hasattr(rel.target_part, "element"):
            yield rel.target_part.element, "hdrftr"


def normalize(doc, force=False):
    f = K.F.fonts
    st = Counter()
    unknown = Counter()
    R = K.Resolver(doc)
    code_id = R.style_id_by_name(K._specs()["code"]["name"])
    code_styles = {code_id} if code_id else set()

    def in_code(rf, kind):
        if kind == "styles":
            s = next(rf.iterancestors(qn("w:style")), None)
            return s is not None and s.get(qn("w:styleId")) in code_styles
        p = next(rf.iterancestors(qn("w:p")), None)
        return p is not None and R.pstyle_id(p) in code_styles

    def east(v):
        role = K.F.role_of.get(v)
        if role in ("body", "heading", "quote"):
            return f[role]
        if role == "code" or v == f["latin"]:
            return f["body"]
        return None

    for root, kind in _parts(doc):
        for rf in root.iter(qn("w:rFonts")):
            for a in K.THEME_ATTRS:
                if rf.get(qn(a)) is not None:
                    del rf.attrib[qn(a)]
                    st["主題字型屬性"] += 1
            code = in_code(rf, kind)
            v = rf.get(qn("w:eastAsia"))
            if v is not None and v not in K.F.allowed_fonts - {f["latin"], f["code"]}:
                new = east(v)
                if new is None:
                    unknown[v] += 1
                    if force:
                        new = f["body"]
                if new and new != v:
                    rf.set(qn("w:eastAsia"), new)
                    st["中文字型"] += 1
            for a in ("w:ascii", "w:hAnsi", "w:cs"):
                v = rf.get(qn(a))
                if v is None:
                    continue
                if code or K.F.role_of.get(v) == "code":
                    want = f["code"]
                else:
                    want = f["latin"]
                if v != want:
                    rf.set(qn(a), want)
                    st["西文字型"] += 1

    # 圖片段落：固定行高會裁切圖片
    fig = K.S(doc, "figure")
    for p in K.iter_paragraphs(doc, include_tables=True):
        if not K.has_media(p._p):
            continue
        line, rule = R.spacing(p._p)
        if rule != "exact":
            continue
        pf = p.paragraph_format
        if not K.ptext(p._p).strip() and p._p.getparent().tag == qn("w:body"):
            p.style = fig
            pPr = p._p.find(qn("w:pPr"))
            for tag in ("w:spacing", "w:ind", "w:jc"):
                e = pPr.find(qn(tag)) if pPr is not None else None
                if e is not None:
                    pPr.remove(e)
        else:
            pf.line_spacing_rule = WD_LINE_SPACING.SINGLE
        st["圖片段落行距"] += 1
    return st, unknown


def main():
    ap = argparse.ArgumentParser(description="字型歸一與圖片段落行距修正")
    ap.add_argument("docx")
    ap.add_argument("--force", action="store_true", help="不認得的中文字型也換成正文字型")
    a = ap.parse_args()
    doc = K.open_document(a.docx, quiet=True)
    st, unknown = normalize(doc, a.force)
    doc.save(a.docx)
    if st:
        print("字型歸一：" + "、".join("%s %d 處" % kv for kv in st.items()))
    else:
        print("字型歸一：無需修改。")
    if unknown:
        print("【待確認】不在規範內的中文字型：" + "、".join("%s（%d）" % kv for kv in unknown.items())
              + ("；已換成正文字型。" if a.force else "；未更改，確認後可加 --force。"))


if __name__ == "__main__":
    main()
