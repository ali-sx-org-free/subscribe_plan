# -*- coding: utf-8 -*-
"""程式碼區塊著色：把一行程式碼寫成多個帶顏色的 run。

配色取自 format.json 的 code.themes（light 淺灰底／dark 深色底），由 code.theme 選擇。
西文用等寬字型，中文用正文字型。支援 plain、yaml、json、sql、bash。

注意：Word 存檔時會把行首空白轉成不間斷空格 U+00A0，判斷縮排時兩者都要當空白。
"""
from __future__ import annotations

import re

from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

import docxkit as K

_NUM = re.compile(r"^-?\d+(\.\d+)?$")
_VAR = re.compile(r"(\$\{[^}]*\}|\$[A-Za-z_][A-Za-z0-9_]*)")
_SQL_KW = set("""SELECT FROM WHERE AND OR NOT NULL IS IN AS ON JOIN LEFT RIGHT INNER OUTER GROUP BY
ORDER HAVING LIMIT OFFSET INSERT INTO VALUES UPDATE SET DELETE CREATE TABLE PRIMARY KEY DEFAULT
COMMENT INDEX UNIQUE BIGINT VARCHAR INT INTEGER DATETIME DATE TEXT DECIMAL AUTO_INCREMENT ENGINE
CHARSET IF EXISTS REFERENCES FOREIGN ALTER ADD DROP CASE WHEN THEN ELSE END DISTINCT COUNT SUM
AVG MIN MAX UNION ALL WITH""".split())
_BASH_KW = set("if then else elif fi for in do done while case esac function return export local".split())


def _theme():
    return K.F.code_theme


def _run(par, text, color_key):
    if not text:
        return
    r = par.add_run(text)
    rPr = r._r.get_or_add_rPr()
    K.set_rfonts(rPr, east=K.F.fonts["body"], latin=K.F.fonts["code"])
    r.font.size = Pt(K.F.size["code"])
    r.font.color.rgb = RGBColor.from_string(_theme()[color_key])


def _value(par, val):
    """值的部分：字串、變數、數值與布林分色。"""
    i = 0
    while i < len(val):
        ch = val[i]
        if ch in "'\"":
            j = val.find(ch, i + 1)
            j = len(val) - 1 if j == -1 else j
            _run(par, val[i:j + 1], "string")
            i = j + 1
            continue
        m = _VAR.match(val, i)
        if m:
            _run(par, m.group(1), "variable")
            i = m.end()
            continue
        j = i
        while j < len(val) and val[j] not in "'\"$":
            j += 1
        for tok in re.split(r"([,\[\]{}:\s]+)", val[i:j] or val[i]):
            if not tok:
                continue
            if _NUM.match(tok) or tok in ("true", "false", "null", "yes", "no", "True", "False", "None"):
                _run(par, tok, "number")
            else:
                _run(par, tok, "default")
        i = max(j, i + 1)


def _split_comment(line, mark):
    """切出行尾註解（引號內的 # 不算）。"""
    q = None
    for i, ch in enumerate(line):
        if ch in "'\"":
            q = None if q == ch else (q or ch)
        elif q is None and line.startswith(mark, i) and (i == 0 or line[i - 1] in " \t\xa0"):
            return line[:i], line[i:]
    return line, ""


def _indent(par, code):
    body = code.lstrip(" \xa0\t")
    lead = code[:len(code) - len(body)].replace(" ", "\xa0").replace("\t", "\xa0" * 4)
    _run(par, lead, "default")
    return body


def _yaml(par, line):
    code, comment = _split_comment(line, "#")
    body = _indent(par, code)
    if body.startswith("- "):
        _run(par, "- ", "default")
        body = body[2:]
    # 鍵：裸字或引號字串，後接冒號與空白（或行尾）；網址中的冒號不會被誤判
    m = re.match(r'^([\w.\-/]+|"[^"]*"|\'[^\']*\')(\s*:)(\s+|$)(.*)$', body)
    if m:
        _run(par, m.group(1), "key")
        _run(par, m.group(2) + m.group(3), "default")
        _value(par, m.group(4))
    else:
        _value(par, body)
    _run(par, comment, "comment")


def _sql(par, line):
    i = line.find("--")
    code, comment = (line[:i], line[i:]) if i >= 0 else (line, "")
    body = _indent(par, code)
    for tok in re.split(r"([A-Za-z_][A-Za-z0-9_]*|'[^']*'|\s+|\W)", body):
        if not tok:
            continue
        if tok.upper() in _SQL_KW:
            _run(par, tok, "keyword")
        elif tok.startswith("'"):
            _run(par, tok, "string")
        elif re.fullmatch(r"\d+(\.\d+)?", tok):
            _run(par, tok, "number")
        else:
            _run(par, tok, "default")
    _run(par, comment, "comment")


def _bash(par, line):
    code, comment = _split_comment(line, "#")
    body = _indent(par, code)
    for tok in re.split(r"(\s+|'[^']*'|\"[^\"]*\"|\$\{[^}]*\}|\$[A-Za-z_]\w*)", body):
        if not tok:
            continue
        if tok in _BASH_KW:
            _run(par, tok, "keyword")
        elif tok[:1] in "'\"":
            _run(par, tok, "string")
        elif tok.startswith("$"):
            _run(par, tok, "variable")
        else:
            _run(par, tok, "default")
    _run(par, comment, "comment")


def _plain(par, line):
    body = _indent(par, line)
    _run(par, body, "default")


def render(par, line, lang="plain"):
    """清空段落並以指定語言著色重建。"""
    for r in list(par.runs):
        r._r.getparent().remove(r._r)
    line = line.rstrip()
    {"yaml": _yaml, "yml": _yaml, "json": _yaml, "sql": _sql, "bash": _bash, "sh": _bash,
     "shell": _bash}.get(lang.lower(), _plain)(par, line)
    return par


def rerender(doc, lang="plain"):
    """重新著色文件中全部「程式碼」樣式段落（例如改了 code.theme 之後）。"""
    name = K._specs()["code"]["name"]
    n = 0
    for p in K.iter_paragraphs(doc):
        if p.style.name == name:
            render(p, K.ptext(p._p).replace("\xa0", " "), lang)
            n += 1
    return n
