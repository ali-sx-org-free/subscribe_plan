# -*- coding: utf-8 -*-
"""docxkit：Word 正式文件共用工具庫（新建、就地編輯、套用版式、重新編號）。

所有排版數值讀自套件根目錄的 format.json；換格式只改那個檔案。
格式由 Word「樣式」承載（標題 1–3、內文、表格內文……），人在 Word 裡
直接從樣式庫套用即可得到相同效果；程式只在必要處加直接格式。

快速上手（完整說明見 docs/5-工具與檢查.md）：

    from docxkit import *
    doc = new_document()
    w = Writer(doc)                       # 游標在文末，依序寫入
    w.title("文件題名", sub="副題", meta=["v0.1 討論稿 · 2026-10-12"])
    w.toc()
    w.body_section("文件題名")            # 正文節：頁首文件名、頁碼自 1 起
    w.h1("一、背景")
    w.p("正文，**粗體引導句**後接說明。")
    w.table("表題", ["欄位", "說明"], [["甲", "乙"]], widths_cm=[4, 12])
    doc.save("文件_v0.1.docx")

    doc = open_document("文件_v0.2.docx")
    anchor = find(doc, "二、")            # 找到唯一一段
    Writer(doc, after=anchor).p("插在「二、」之後的新段落。")
"""
from __future__ import annotations

import copy
import json
import os
import re
import sys
from pathlib import Path
from types import SimpleNamespace

from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn
from docx.shared import Cm, Emu, Pt, RGBColor
from docx.styles.style import StyleFactory
from docx.table import Table
from docx.text.paragraph import Paragraph

__all__ = [
    "F", "use_format", "new_document", "open_document", "apply_format", "Writer",
    "find", "find_all", "set_text", "delete", "replace_table", "renumber",
    "has_media", "iter_blocks", "iter_paragraphs", "ptext", "lock_file",
    "tracked_changes", "read_comments", "find_toc_span", "style_key", "EditError",
    "Resolver", "S", "page_setup",
]

ROOT = Path(__file__).resolve().parent.parent
W_P, W_TBL, W_SDT = qn("w:p"), qn("w:tbl"), qn("w:sdt")
THEME_ATTRS = ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme")

try:  # 讓 Windows 終端機或重導向輸出時不因少數符號報錯
    sys.stdout.reconfigure(errors="replace")
    sys.stderr.reconfigure(errors="replace")
except Exception:
    pass


class EditError(RuntimeError):
    """就地編輯被保護機制擋下（含圖片、功能變數、超連結、找不到或找到多處）。"""


# ════════════════════════════════════════════════════════════════════
# 一、讀取 format.json
# ════════════════════════════════════════════════════════════════════

F = SimpleNamespace()


def use_format(path=None, profile=None):
    """載入排版契約。path 預設為套件根目錄 format.json，也可用環境變數 DOCX_FORMAT 指定；
    profile 預設取檔內 "profile"，也可用環境變數 DOCX_PROFILE 指定（zh-Hant／zh-Hans）。"""
    path = Path(path or os.environ.get("DOCX_FORMAT") or ROOT / "format.json")
    data = json.loads(path.read_text(encoding="utf-8"))
    name = profile or os.environ.get("DOCX_PROFILE") or data["profile"]
    prof = data["profiles"][name]
    F.__dict__.clear()
    F.path, F.raw, F.profile = path, data, name
    F.lang = prof["lang"]
    F.fonts = prof["fonts"]
    F.labels = prof["labels"]
    F.names = prof["styleNames"]
    F.page = data["page"]
    F.size = data["sizePt"]
    F.line = data["lineSpacingPt"]
    F.space = data["spacingPt"]
    F.indent = data["indentChars"]
    F.headings = data["headings"]
    F.color = data["colors"]
    F.table = data["table"]
    F.callout = data["callout"]
    F.code = data["code"]
    F.code_theme = data["code"]["themes"][data["code"]["theme"]]
    F.content = data["content"]
    F.text_width_cm = F.page["widthCm"] - F.page["marginLeftCm"] - F.page["marginRightCm"]
    F.role_of = {}
    for role, names in data["fontRoles"].items():
        if role.startswith("_"):
            continue
        for n in names:
            F.role_of.setdefault(n, role)
    for role, n in F.fonts.items():
        F.role_of[n] = role
    # 規範內允許出現的字型
    F.allowed_fonts = set(F.fonts.values())
    return F


use_format()


# ════════════════════════════════════════════════════════════════════
# 二、XML 小工具：依 schema 順序插入子元素
# ════════════════════════════════════════════════════════════════════

_SEQ = {
    "w:pPr": "pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr "
             "suppressLineNumbers pBdr shd tabs suppressAutoHyphens kinsoku wordWrap "
             "overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd "
             "snapToGrid spacing ind contextualSpacing mirrorIndents suppressOverlap jc "
             "textDirection textAlignment textboxTightWrap outlineLvl divId cnfStyle rPr "
             "sectPr pPrChange",
    "w:rPr": "rStyle rFonts b bCs i iCs caps smallCaps strike dstrike outline shadow emboss "
             "imprint noProof snapToGrid vanish webHidden color spacing w kern position sz "
             "szCs highlight u effect bdr shd fitText vertAlign rtl cs em lang "
             "eastAsianLayout specVanish oMath",
    "w:tblPr": "tblStyle tblpPr tblOverlap bidiVisual tblStyleRowBandSize tblStyleColBandSize "
               "tblW jc tblCellSpacing tblInd tblBorders shd tblLayout tblCellMar tblLook "
               "tblCaption tblDescription",
    "w:tcPr": "cnfStyle tcW gridSpan hMerge vMerge tcBorders shd noWrap tcMar textDirection "
              "tcFitText vAlign hideMark",
    "w:sectPr": "headerReference footerReference footnotePr endnotePr type pgSz pgMar paperSrc "
                "pgBorders lnNumType pgNumType cols formProt vAlign noEndnote titlePg "
                "textDirection bidi rtlGutter docGrid printerSettings sectPrChange",
    "w:settings": "writeProtection view zoom removePersonalInformation removeDateAndTime "
                  "doNotDisplayPageBoundaries displayBackgroundShape printPostScriptOverText "
                  "printFractionalCharacterWidth printFormsData embedTrueTypeFonts "
                  "embedSystemFonts saveSubsetFonts saveFormsData mirrorMargins "
                  "alignBordersAndEdges bordersDoNotSurroundHeader bordersDoNotSurroundFooter "
                  "gutterAtTop hideSpellingErrors hideGrammaticalErrors activeWritingStyle "
                  "proofState formsDesign attachedTemplate linkStyles stylePaneFormatFilter "
                  "stylePaneSortMethod documentType mailMerge revisionView trackRevisions "
                  "doNotTrackMoves doNotTrackFormatting documentProtection autoFormatOverride "
                  "styleLockTheme styleLockQFSet defaultTabStop autoHyphenation "
                  "consecutiveHyphenLimit hyphenationZone doNotHyphenateCaps showEnvelope "
                  "summaryLength clickAndTypeStyle defaultTableStyle evenAndOddHeaders "
                  "bookFoldRevPrinting bookFoldPrinting bookFoldPrintingSheets "
                  "drawingGridHorizontalSpacing drawingGridVerticalSpacing "
                  "displayHorizontalDrawingGridEvery displayVerticalDrawingGridEvery "
                  "doNotUseMarginsForDrawingGridOrigin drawingGridHorizontalOrigin "
                  "drawingGridVerticalOrigin doNotShadeFormData noPunctuationKerning "
                  "characterSpacingControl printTwoOnOne strictFirstAndLastChars "
                  "noLineBreaksAfter noLineBreaksBefore savePreviewPicture "
                  "doNotValidateAgainstSchema saveInvalidXml ignoreMixedContent "
                  "alwaysShowPlaceholderText doNotDemarcateInvalidXml saveXmlDataOnly "
                  "useXSLTWhenSaving saveThroughXslt showXMLTags alwaysMergeEmptyNamespace "
                  "updateFields hdrShapeDefaults footnotePr endnotePr compat docVars rsids "
                  "mathPr attachedSchema themeFontLang clrSchemeMapping "
                  "doNotIncludeSubdocsInStats doNotAutoCompressPictures forceUpgrade captions "
                  "readModeInkLockDown smartTagType schemaLibrary shapeDefaults "
                  "doNotEmbedSmartTags decimalSymbol listSeparator",
}
_SEQ = {qn(k): [qn("w:" + t) for t in v.split()] for k, v in _SEQ.items()}


def put(parent, child):
    """把 child 放進 parent 的正確位置（同名舊元素先移除）。Word 對子元素順序敏感，
    順序錯誤可能導致「無法讀取的內容」，所以一律經過這裡。"""
    for old in parent.findall(child.tag):
        parent.remove(old)
    seq = _SEQ.get(parent.tag)
    if seq and child.tag in seq:
        later = set(seq[seq.index(child.tag) + 1:])
        for el in parent:
            if el.tag in later:
                el.addprevious(child)
                return child
    parent.append(child)
    return child


def el(tag, **attrs):
    e = OxmlElement(tag)
    for k, v in attrs.items():
        e.set(qn("w:" + k), str(v))
    return e


def set_rfonts(rPr, east=None, latin=None, hint=False, strip_theme=True):
    """設定字型：east＝中文字型，latin＝西文與數字字型；預設移除主題字型屬性
    （主題字型屬性會蓋過明確字型，是「標題字型不對、新內容變 Cambria」的根因）。"""
    rf = rPr.find(qn("w:rFonts"))
    if rf is None:
        rf = put(rPr, OxmlElement("w:rFonts"))
    if strip_theme:
        for a in THEME_ATTRS:
            rf.attrib.pop(qn(a), None)
    if east:
        rf.set(qn("w:eastAsia"), east)
    if latin:
        for a in ("w:ascii", "w:hAnsi", "w:cs"):
            rf.set(qn(a), latin)
    if hint:
        rf.set(qn("w:hint"), "eastAsia")
    return rf


def _hex(c):
    return RGBColor.from_string(c.upper())


def _twips(cm):
    return int(round(cm / 2.54 * 1440))


# ════════════════════════════════════════════════════════════════════
# 三、樣式規格（全部由 format.json 推導）
# ════════════════════════════════════════════════════════════════════

def _specs():
    s, ln, sp, c, fn, nm = F.size, F.line, F.space, F.color, F.fonts, F.names
    body_indent = Pt(s["body"] * F.indent["body"])
    quote_indent = Pt(s["body"] * F.indent["quote"])
    J, L, C = WD_ALIGN_PARAGRAPH.JUSTIFY, WD_ALIGN_PARAGRAPH.LEFT, WD_ALIGN_PARAGRAPH.CENTER
    tw = F.text_width_cm

    def spec(name, base, role, size, color, align, line, before=0, after=0, bold=False,
             first=Pt(0), left=Pt(0), **extra):
        d = dict(name=name, base=base, role=role, size=size, color=color, align=align,
                 line=line, before=before, after=after, bold=bold, first=first, left=left)
        d.update(extra)
        return d

    return {
        "normal": spec("Normal", None, "body", s["body"], c["text"], J, ln["body"],
                       *sp["body"], first=body_indent, widow=True),
        "h1": spec("Heading 1", "Normal", "heading", s["h1"], c["title"], L, ln["h1"], *sp["h1"],
                   keep_next=True, keep_lines=True),
        "h2": spec("Heading 2", "Normal", "heading", s["h2"], c["text"], L, ln["h2"], *sp["h2"],
                   keep_next=True, keep_lines=True),
        "h3": spec("Heading 3", "Normal", "heading", s["h3"], c["text"], L, ln["h3"], *sp["h3"],
                   bold=True, keep_next=True, keep_lines=True),
        "title": spec(nm["title"], "Normal", "heading", s["title"], c["title"], C, ln["title"],
                      *sp["title"], custom=True),
        "subtitle": spec(nm["subtitle"], "Normal", "quote", s["body"], c["aux"], C, ln["body"],
                         0, 6, custom=True),
        "meta": spec(nm["meta"], "Normal", "body", s["body"], c["aux"], C, ln["body"], custom=True),
        "tocTitle": spec(nm["tocTitle"], "Normal", "heading", s["h1"], c["title"], C, ln["h1"],
                         0, 12, custom=True, page_break=True),
        "toc1": spec("toc 1", "Normal", "body", s["body"], c["text"], J, ln["body"], 3, 0,
                     toc=True),
        "toc2": spec("toc 2", "Normal", "body", s["body"], c["text"], J, ln["body"],
                     left=Pt(s["body"] * 2), toc=True),
        "toc3": spec("toc 3", "Normal", "body", s["body"], c["text"], J, ln["body"],
                     left=Pt(s["body"] * 4), toc=True),
        "quote": spec(nm["quote"], "Normal", "quote", s["body"], c["text"], J, ln["body"],
                      *sp["quote"], left=quote_indent, custom=True),
        "callout": spec(nm["callout"], "Normal", "body", s["body"], c["text"], J, ln["body"],
                        *sp["callout"], custom=True, keep_lines=True, callout=True),
        "caption": spec("Caption", "Normal", "heading", s["caption"], c["text"], C, ln["caption"],
                        *sp["caption"], keep_next=True),
        "source": spec(nm["source"], "Normal", "body", s["source"], c["aux"], L, ln["caption"],
                       *sp["source"], custom=True),
        "tableText": spec(nm["tableText"], "Normal", "body", s["table"], c["text"], L,
                          ln["table"], custom=True),
        "tableHead": spec(nm["tableHead"], nm["tableText"], "heading", s["table"], c["text"], C,
                          ln["table"], bold=True, custom=True),
        "figure": spec(nm["figure"], "Normal", "body", s["body"], c["text"], C, None,
                       *sp["figure"], custom=True, keep_next=True),
        "code": spec(nm["code"], "Normal", "code", F.size["code"], F.code_theme["default"], L,
                     F.line["code"], custom=True, shade=F.code_theme["background"]),
        "header": spec("Header", "Normal", "body", s["header"], c["header"], C, None,
                       border_bottom=c["line"]),
        "footer": spec("Footer", "Normal", "body", s["header"], c["aux"], C, None),
        "_tab_pos": _twips(tw),
    }


def _find_style(doc, name):
    """以樣式的內部名稱找樣式（不分大小寫），找不到回傳 None。"""
    low = name.lower()
    for s in doc.styles.element.findall(qn("w:style")):
        n = s.find(qn("w:name"))
        if n is not None and (n.get(qn("w:val")) or "").lower() == low:
            return StyleFactory(s)
    return None


def _get_or_add_style(doc, spec):
    st = _find_style(doc, spec["name"])
    if st is not None:
        return st
    if spec.get("toc"):  # 目錄條目樣式需用 Word 內建名稱，Word 更新目錄時才會套用
        sid = spec["name"].replace(" ", "").upper()
        doc.styles.element.append(parse_xml(
            '<w:style %s w:type="paragraph" w:styleId="%s"><w:name w:val="%s"/>'
            '<w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:uiPriority w:val="39"/>'
            '<w:unhideWhenUsed/></w:style>' % (nsdecls("w"), sid, spec["name"])))
        return _find_style(doc, spec["name"])
    st = doc.styles.add_style(spec["name"], WD_STYLE_TYPE.PARAGRAPH)
    return st


def _apply_style(doc, spec, tab_pos):
    st = _get_or_add_style(doc, spec)
    if spec["base"]:
        base = _find_style(doc, spec["base"])
        if base is not None and spec["name"] != "Normal":
            st.base_style = base
    if spec.get("custom") or spec.get("toc"):
        st.hidden = False
        st.quick_style = bool(spec.get("custom"))
    if spec["name"] == "Caption":
        st.hidden = False
        st.quick_style = True
    st.font.size = Pt(spec["size"])
    st.font.bold = spec["bold"]
    st.font.italic = False
    st.font.color.rgb = _hex(spec["color"])
    rPr = st.element.get_or_add_rPr()
    if spec["role"] == "code":
        set_rfonts(rPr, east=F.fonts["body"], latin=F.fonts["code"])
    else:
        set_rfonts(rPr, east=F.fonts[spec["role"]], latin=F.fonts["latin"])
    pf = st.paragraph_format
    pf.alignment = spec["align"]
    pf.first_line_indent = spec["first"]
    pf.left_indent = spec["left"]
    pf.right_indent = Pt(0)
    if spec["line"] is None:
        pf.line_spacing_rule = WD_LINE_SPACING.SINGLE
    else:
        pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
        pf.line_spacing = Pt(spec["line"])
    pf.space_before = Pt(spec["before"])
    pf.space_after = Pt(spec["after"])
    pf.widow_control = True
    pf.keep_with_next = bool(spec.get("keep_next")) or None
    pf.keep_together = bool(spec.get("keep_lines")) or None
    pf.page_break_before = bool(spec.get("page_break")) or None
    pPr = st.element.get_or_add_pPr()
    if spec.get("callout"):
        bd = el("w:pBdr")
        bd.append(el("w:left", val="single", sz=int(F.callout["borderPt"] * 8), space=8,
                     color=F.callout["borderColor"]))
        put(pPr, bd)
        put(pPr, el("w:shd", val="clear", color="auto", fill=F.color["shade"]))
        pf.left_indent = Pt(6)
        pf.right_indent = Pt(6)
    if spec.get("shade"):
        put(pPr, el("w:shd", val="clear", color="auto", fill=spec["shade"]))
    if spec.get("border_bottom"):
        bd = el("w:pBdr")
        bd.append(el("w:bottom", val="single", sz=4, space=1, color=spec["border_bottom"]))
        put(pPr, bd)
    if spec.get("toc"):
        tabs = el("w:tabs")
        tabs.append(el("w:tab", val="right", leader="dot", pos=tab_pos))
        put(pPr, tabs)
    if spec["name"] in ("Header", "Footer"):
        tabs = pPr.find(qn("w:tabs"))
        if tabs is not None:
            pPr.remove(tabs)
    return st


def _setup_theme(doc):
    """把佈景主題字型也換成規範字型：使用者在 Word 新打的內容若套到主題字型，仍會落在規範內。"""
    try:
        part = doc.part.part_related_by(RT.THEME)
    except KeyError:
        return
    xml = part.blob.decode("utf-8")
    lat, body, head = F.fonts["latin"], F.fonts["body"], F.fonts["heading"]

    def fix(block, cjk):
        block = re.sub(r'(<a:latin typeface=")[^"]*(")', r"\g<1>%s\2" % lat, block)
        block = re.sub(r'(<a:font script="Han[st]" typeface=")[^"]*(")', r"\g<1>%s\2" % cjk, block)
        return block

    xml = re.sub(r"<a:majorFont>.*?</a:majorFont>", lambda m: fix(m.group(0), head), xml, flags=re.S)
    xml = re.sub(r"<a:minorFont>.*?</a:minorFont>", lambda m: fix(m.group(0), body), xml, flags=re.S)
    part._blob = xml.encode("utf-8")


def _setup_defaults(doc):
    styles = doc.styles.element
    dd = styles.find(qn("w:docDefaults"))
    if dd is None:
        dd = parse_xml("<w:docDefaults %s/>" % nsdecls("w"))
        styles.insert(0, dd)
    rd = dd.find(qn("w:rPrDefault"))
    if rd is None:
        rd = el("w:rPrDefault")
        dd.insert(0, rd)
    rPr = rd.find(qn("w:rPr"))
    if rPr is None:
        rPr = el("w:rPr")
        rd.append(rPr)
    set_rfonts(rPr, east=F.fonts["body"], latin=F.fonts["latin"])
    put(rPr, el("w:sz", val=int(F.size["body"] * 2)))
    put(rPr, el("w:szCs", val=int(F.size["body"] * 2)))
    put(rPr, el("w:lang", val="en-US", eastAsia=F.lang, bidi="ar-SA"))
    pd = dd.find(qn("w:pPrDefault"))
    if pd is None:
        pd = el("w:pPrDefault")
        dd.append(pd)
    pPr = pd.find(qn("w:pPr"))
    if pPr is None:
        pPr = el("w:pPr")
        pd.append(pPr)
    put(pPr, el("w:spacing", after=0, line=240, lineRule="auto"))
    # 其餘樣式（含內建未使用者）一律移除主題字型屬性，避免 Word 改用佈景主題字型
    for rf in styles.iter(qn("w:rFonts")):
        had = any(rf.get(qn(a)) is not None for a in THEME_ATTRS)
        for a in THEME_ATTRS:
            rf.attrib.pop(qn(a), None)
        if had and rf.get(qn("w:eastAsia")) is None:
            rf.set(qn("w:eastAsia"), F.fonts["heading"])
            for a in ("w:ascii", "w:hAnsi", "w:cs"):
                rf.set(qn(a), F.fonts["latin"])


def _setup_settings(doc):
    s = doc.settings.element
    put(s, el("w:updateFields", val="true"))  # 開檔時更新目錄等功能變數


def page_setup(section, landscape=False):
    p = F.page
    w, h = Cm(p["widthCm"]), Cm(p["heightCm"])
    section.orientation = WD_ORIENT.LANDSCAPE if landscape else WD_ORIENT.PORTRAIT
    section.page_width, section.page_height = (h, w) if landscape else (w, h)
    section.top_margin, section.bottom_margin = Cm(p["marginTopCm"]), Cm(p["marginBottomCm"])
    section.left_margin, section.right_margin = Cm(p["marginLeftCm"]), Cm(p["marginRightCm"])
    section.header_distance, section.footer_distance = Cm(p["headerCm"]), Cm(p["footerCm"])
    section.gutter = Cm(0)


def apply_format(doc):
    """把 format.json 的版式套到文件：樣式、預設字型、佈景主題字型、頁面設定。
    不改動任何內文文字。用於新建文件，也可用於接手的既有文件。"""
    _setup_theme(doc)
    _setup_defaults(doc)
    specs = _specs()
    tab = specs.pop("_tab_pos")
    for key in ("normal", "h1", "h2", "h3", "tableText"):  # 先建被繼承的樣式
        _apply_style(doc, specs[key], tab)
    for key, spec in specs.items():
        if key not in ("normal", "h1", "h2", "h3", "tableText"):
            _apply_style(doc, spec, tab)
    _setup_settings(doc)
    for sec in doc.sections:
        page_setup(sec, landscape=sec.orientation == WD_ORIENT.LANDSCAPE)
    return doc


def new_document():
    """建立一份已套好版式的空白文件。"""
    doc = Document()
    body = doc.element.body
    for child in list(body):
        if child.tag != qn("w:sectPr"):
            body.remove(child)
    # 清掉範本自帶的檔案屬性（作者 python-docx、2013 年建立日期）
    import datetime as _dt
    cp = doc.core_properties
    now = _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0, tzinfo=None)
    cp.author, cp.last_modified_by, cp.title, cp.subject, cp.keywords, cp.comments = "", "", "", "", "", ""
    cp.created, cp.modified, cp.revision = now, now, 1
    apply_format(doc)
    return doc


def S(doc, key):
    """取得規範樣式物件，key 見 _specs()：normal h1 h2 h3 title quote callout caption code…"""
    spec = _specs()[key]
    st = _find_style(doc, spec["name"])
    if st is None:
        raise EditError("文件缺少樣式「%s」，請先執行 apply_format(doc)。" % spec["name"])
    return st


def style_key(style_name):
    """由樣式名稱反查規範中的 key；不在規範內回傳 None。"""
    low = (style_name or "").lower()
    for k, v in _specs().items():
        if k.startswith("_"):
            continue
        if v["name"].lower() == low:
            return k
    return None


# ════════════════════════════════════════════════════════════════════
# 四、讀取與定位
# ════════════════════════════════════════════════════════════════════

def ptext(p_el):
    """段落的實際文字（含修訂插入、超連結；不含已刪除文字）。"""
    out = []
    for e in p_el.iter(qn("w:t"), qn("w:tab"), qn("w:br")):
        if e.tag == qn("w:t"):
            out.append(e.text or "")
        elif e.tag == qn("w:tab"):
            out.append(" ")
    return "".join(out)


def has_media(par_or_el):
    x = getattr(par_or_el, "_p", par_or_el)
    return any(x.find(".//" + qn(t)) is not None for t in ("w:drawing", "w:pict", "w:object"))


def iter_blocks(doc, into_sdt=True):
    """依文件順序產生正文的 Paragraph 與 Table（不含表格儲存格內的段落）。"""
    def walk(parent):
        for e in parent.iterchildren():
            if e.tag == W_P:
                yield Paragraph(e, doc._body)
            elif e.tag == W_TBL:
                yield Table(e, doc._body)
            elif e.tag == W_SDT and into_sdt:
                c = e.find(qn("w:sdtContent"))
                if c is not None:
                    yield from walk(c)
    yield from walk(doc.element.body)


def iter_paragraphs(doc, include_tables=False):
    for b in iter_blocks(doc):
        if isinstance(b, Paragraph):
            yield b
        elif include_tables:
            for row in b.rows:
                seen = set()
                for cell in row.cells:
                    if id(cell._tc) in seen:
                        continue
                    seen.add(id(cell._tc))
                    yield from cell.paragraphs


def _matcher(match):
    if callable(match):
        return match
    if hasattr(match, "search"):
        return lambda t: bool(match.search(t))
    return lambda t: t.strip().startswith(match)


def find_all(doc, match, include_tables=False, style=None):
    """回傳所有符合的段落。match：字串＝段首相同；re.compile(...)＝正則搜尋；函式＝自訂判斷。"""
    m = _matcher(match)
    out = []
    skip = _toc_members(doc)  # 目錄條目與正文標題同名，一律排除
    for p in iter_paragraphs(doc, include_tables):
        if p._p in skip:
            continue
        if style and p.style.name != style:
            continue
        if m(ptext(p._p)):
            out.append(p)
    return out


def find(doc, match, include_tables=False, style=None):
    """回傳唯一符合的段落；找不到或找到多處都會報錯並列出候選，避免改錯地方。"""
    hits = find_all(doc, match, include_tables, style)
    if len(hits) == 1:
        return hits[0]
    if not hits:
        raise EditError("找不到符合「%s」的段落。" % getattr(match, "pattern", match))
    lines = "\n".join("  · %s" % ptext(h._p)[:40] for h in hits[:8])
    raise EditError("「%s」符合 %d 處，請改用更精確的條件：\n%s"
                    % (getattr(match, "pattern", match), len(hits), lines))


def lock_file(path):
    """Word 開啟中的文件旁會有 ~$ 開頭的鎖定檔；回傳其路徑或 None。"""
    path = Path(path)
    for f in path.parent.glob("~$*"):
        if path.name.endswith(f.name[2:]) or f.name[2:] == path.name:
            return f
    return None


def tracked_changes(doc):
    body = doc.element.body
    ins = len(body.findall(".//" + qn("w:ins")))
    dele = len(body.findall(".//" + qn("w:del")))
    return ins, dele


def read_comments(doc):
    """讀出 Word 註解：[(編號, 作者, 內容, 錨定段落文字)]。使用者可用註解給 agent 下指示。"""
    part = None
    for rel in doc.part.rels.values():
        if rel.reltype.endswith("/comments") and not rel.is_external:
            part = rel.target_part
            break
    if part is None:
        return []
    root = part.element if hasattr(part, "element") else parse_xml(part.blob)
    anchors = {}
    for p in doc.element.body.iter(W_P):
        for e in p.iter(qn("w:commentRangeStart"), qn("w:commentReference")):
            anchors.setdefault(e.get(qn("w:id")), ptext(p))
    out = []
    for c in root.findall(qn("w:comment")):
        cid = c.get(qn("w:id"))
        text = " ".join(ptext(p) for p in c.iter(W_P)).strip()
        out.append((cid, c.get(qn("w:author")) or "", text, anchors.get(cid, "")))
    return out


def open_document(path, quiet=False):
    """開啟既有文件並提示風險：Word 仍開著、含修訂標記、含註解。"""
    doc = Document(str(path))
    if not quiet:
        lk = lock_file(path)
        if lk:
            print("【注意】偵測到 Word 鎖定檔 %s：使用者可能仍開著此檔，"
                  "其後存檔會覆蓋腳本結果。請先請使用者關閉。" % lk.name, file=sys.stderr)
        ins, dele = tracked_changes(doc)
        if ins or dele:
            print("【注意】文件含修訂標記（插入 %d、刪除 %d）。請使用者先在 Word 接受或拒絕"
                  "全部修訂，否則差異比對與改寫可能不準。" % (ins, dele), file=sys.stderr)
        cm = read_comments(doc)
        if cm:
            print("【提示】文件含 %d 則註解，可能是使用者給你的指示，請逐條讀取處理。" % len(cm),
                  file=sys.stderr)
    return doc


# ════════════════════════════════════════════════════════════════════
# 五、Writer：唯一的寫入入口（新建時在文末追加；編輯時插在錨點之後）
# ════════════════════════════════════════════════════════════════════

_BOLD = re.compile(r"\*\*(.+?)\*\*")
_CJK = re.compile(r"[　-〿㐀-鿿＀-￯‘-”…—]")
_NUM = re.compile(r"^[-+±]?[\d,，.]+%?$|^[-+±]?\d[\d,，.]*\s*[%‰萬万億亿元個个件次人天日]$")


def add_runs(par, text, bold_all=False):
    """寫入文字；**…** 標記為強調（粗體＋標題字型）。中文 run 加 eastAsia 提示，
    讓引號、破折號、刪節號以中文字型呈現。"""
    pos = 0
    pieces = []
    for m in _BOLD.finditer(text):
        if m.start() > pos:
            pieces.append((text[pos:m.start()], bold_all))
        pieces.append((m.group(1), True))
        pos = m.end()
    if pos < len(text):
        pieces.append((text[pos:], bold_all))
    for chunk, bold in pieces:
        r = par.add_run(chunk)
        rPr = r._r.get_or_add_rPr()
        if bold:
            r.bold = True
            set_rfonts(rPr, east=F.fonts["heading"], hint=bool(_CJK.search(chunk)))
        elif _CJK.search(chunk):
            set_rfonts(rPr, hint=True)
        if len(rPr) == 0:
            r._r.remove(rPr)
    return par


class Writer:
    """寫入游標。Writer(doc) 在文末追加；Writer(doc, after=段落或表格) 從錨點之後插入，
    每寫一個元素游標就往後移，所以連續呼叫會依序排列。"""

    def __init__(self, doc, after=None):
        self.doc = doc
        self.body = doc.element.body
        self._end = after is None
        self._cur = None if after is None else getattr(after, "_element", after)
        if self._cur is not None and self._cur.getparent() is not self.body:
            if self._cur.getparent().tag != qn("w:sdtContent"):
                raise EditError("錨點必須是正文層級的段落或表格（不能在表格儲存格內）。")
        self._gap = False
        self._break = False
        self._last = None

    # ---- 底層 ----
    def _insert(self, e):
        if self._end:
            sect = self.body.find(qn("w:sectPr"))
            if sect is not None:
                sect.addprevious(e)
            else:
                self.body.append(e)
        else:
            self._cur.addnext(e)
            self._cur = e
        return e

    def text_width_cm(self):
        """目前寫入位置所在節的版心寬度（橫式節較寬）。"""
        sp = None
        if not self._end:
            cur = self._cur
            while cur is not None and sp is None:
                if cur.tag == W_P:
                    sp = cur.find(qn("w:pPr") + "/" + qn("w:sectPr"))
                cur = cur.getnext()
        if sp is None:
            sp = self.body.find(qn("w:sectPr"))
        from docx.section import Section
        sec = Section(sp, self.doc.part)
        return (sec.page_width - sec.left_margin - sec.right_margin) / 360000

    @property
    def last(self):
        """最後寫入的元素（可作為下一個 Writer 的錨點）。"""
        return self._last

    def par(self, text="", key="normal", bold=False):
        p = self._insert(OxmlElement("w:p"))
        par = Paragraph(p, self.doc._body)
        par.style = S(self.doc, key)
        if self._break:
            par.paragraph_format.page_break_before = True
            self._break = False
        if self._gap and key not in ("h1", "h2", "h3", "caption", "tocTitle"):
            par.paragraph_format.space_before = Pt(F.space["afterTable"])
        self._gap = False
        if text:
            add_runs(par, text, bold_all=bold)
        self._last = par
        return par

    # ---- 封面與目錄 ----
    def title(self, text, sub=None, meta=(), top_pt=160):
        """文件題名（封面）。sub＝副題；meta＝版本、日期、單位等資訊行。"""
        t = self.par(text, "title")
        t.paragraph_format.space_before = Pt(top_pt)
        if sub:
            self.par(sub, "subtitle")
        for m in meta:
            self.par(m, "meta")
        return t

    def toc(self):
        """目錄頁：標題「目錄」（段前分頁）＋ TOC 功能變數，Word 開檔時自動更新。"""
        self.par(F.labels["toc"], "tocTitle")
        p = self.par("", "normal")
        p.paragraph_format.first_line_indent = Pt(0)
        _toc_field(p._p)
        return p

    def page_break(self):
        """下一段從新頁開始（以「段落前分頁」實作，不產生空段）。"""
        self._break = True

    def body_section(self, header_text, landscape=False):
        """開始正文節：新頁起、頁首為文件名稱（細線）、頁尾頁碼自 1 起編。只能在文末模式使用。"""
        if not self._end:
            raise EditError("分節只能在新建文件時於文末使用。")
        sec = self.doc.add_section(WD_SECTION.NEW_PAGE)
        page_setup(sec, landscape)
        sec.header.is_linked_to_previous = False
        sec.footer.is_linked_to_previous = False
        hp = sec.header.paragraphs[0]
        hp.style = S(self.doc, "header")
        for r in list(hp.runs):
            r._r.getparent().remove(r._r)
        add_runs(hp, header_text)
        fp = sec.footer.paragraphs[0]
        fp.style = S(self.doc, "footer")
        for r in list(fp.runs):
            r._r.getparent().remove(r._r)
        pre, _, post = F.page["pageNumberFormat"].partition("{n}")
        if pre:
            add_runs(fp, pre)
        _simple_field(fp._p, "PAGE", "1")
        if post:
            add_runs(fp, post)
        put(sec._sectPr, el("w:pgNumType", start=1))
        return sec

    def new_section(self, landscape=False):
        """正文中途另起一節（例如放寬表格的橫式頁），頁碼延續、頁首頁尾沿用上一節。
        放完後再呼叫一次 new_section() 回到直式。只能在文末模式使用。"""
        if not self._end:
            raise EditError("分節只能在新建文件時於文末使用。")
        sec = self.doc.add_section(WD_SECTION.NEW_PAGE)
        page_setup(sec, landscape)
        pg = sec._sectPr.find(qn("w:pgNumType"))
        if pg is not None:
            sec._sectPr.remove(pg)
        return sec

    # ---- 正文 ----
    def h(self, level, text):
        if not 1 <= level <= F.headings["maxLevel"]:
            raise EditError("標題最多 %d 級。" % F.headings["maxLevel"])
        return self.par(text, "h%d" % level)

    def h1(self, text):
        return self.h(1, text)

    def h2(self, text):
        return self.h(2, text)

    def h3(self, text):
        return self.h(3, text)

    def p(self, text):
        """正文段落：首行縮排 2 字、兩端對齊。**…** 為強調。"""
        return self.par(text, "normal")

    def item(self, text):
        """正文列舉，一律以（1）（2）開頭；格式同正文。"""
        return self.par(text, "normal")

    def lead(self, label, text):
        """引導句段落：「**結論：**說明……」，用於讓讀者先看到重點。"""
        return self.par("**%s**%s" % (label, text), "normal")

    def note(self, text):
        """引文或說明：楷體、左縮排 2 字。"""
        return self.par(text, "quote")

    def callout(self, text, label=None):
        """要點框：淺灰底、左側墨藍粗線。一章最多一個，用來放本章結論或必讀要求。"""
        label = F.labels["callout"] if label is None else label
        return self.par(("**%s：**" % label if label else "") + text, "callout")

    # ---- 表格 ----
    def table(self, caption, headers, rows, widths_cm=None, source=None):
        """三線表。caption 不含編號（寫入「表 X　標題」，收尾時統一編號）；
        widths_cm 總和不得超過版心寬度；source＝表下資料來源說明。
        儲存格以 **…** 表示粗體；純數值自動靠右。"""
        if caption:
            self.par("%s X　%s" % (F.labels["table"], caption), "caption")
        t = _build_table(self.doc, headers, rows, widths_cm, self.text_width_cm())
        self._insert(t._tbl)
        self._last = t
        if source:
            self.par(source, "source")
        else:
            self._gap = True
        return t

    # ---- 圖 ----
    def figure(self, image, caption, width_cm=None):
        """插入圖片（單行間距、置中，避免固定行高裁切）與圖下題注「圖 X　標題」。"""
        p = self.par("", "figure")
        tw = self.text_width_cm()
        width = Cm(min(width_cm or tw, tw))
        p.add_run().add_picture(str(image), width=width)
        cap = self.par("%s X　%s" % (F.labels["figure"], caption), "caption")
        cap.paragraph_format.keep_with_next = False
        return p

    # ---- 程式碼 ----
    def code(self, text, lang="plain"):
        """程式碼區塊：每行一段、等寬字型、底色依 format.json code.theme。
        lang：plain／yaml／json／sql／bash。"""
        from codehl import render
        last = None
        lines = text.rstrip("\n").split("\n")
        for k, line in enumerate(lines):
            last = self.par("", "code")
            render(last, line, lang)
            if len(lines) <= 15 and k < len(lines) - 1:
                last.paragraph_format.keep_with_next = True   # 短區塊整塊同頁，不讓註解與指令分家
        self._gap = True
        return last


def _field_runs(p_el, instr, placeholder, dirty=False, rPr=None):
    def run(child):
        r = OxmlElement("w:r")
        if rPr is not None:
            r.append(copy.deepcopy(rPr))
        r.append(child)
        p_el.append(r)
    b = el("w:fldChar", fldCharType="begin")
    if dirty:
        b.set(qn("w:dirty"), "true")
    run(b)
    it = OxmlElement("w:instrText")
    it.set(qn("xml:space"), "preserve")
    it.text = " %s " % instr
    run(it)
    run(el("w:fldChar", fldCharType="separate"))
    t = OxmlElement("w:t")
    t.text = placeholder
    run(t)
    run(el("w:fldChar", fldCharType="end"))


def _simple_field(p_el, instr, placeholder):
    _field_runs(p_el, instr, placeholder)


def _toc_field(p_el):
    rPr = el("w:rPr")
    put(rPr, el("w:color", val=F.color["aux"]))
    _field_runs(p_el, 'TOC \\o "1-%d" \\h \\z \\u' % F.headings["maxLevel"],
                F.labels["tocPlaceholder"], dirty=True, rPr=rPr)


def _border(tag, pt):
    if pt:
        return el(tag, val="single", sz=int(round(pt * 8)), space=0, color="000000")
    return el(tag, val="nil")


def _build_table(doc, headers, rows, widths_cm=None, tw=None):
    n = len(headers)
    tw = tw or F.text_width_cm
    if widths_cm is None:
        widths_cm = [round(tw / n, 2)] * n
    if len(widths_cm) != n:
        raise EditError("欄寬數量（%d）與欄數（%d）不符。" % (len(widths_cm), n))
    if sum(widths_cm) > tw + 0.05:
        raise EditError("表寬 %.2f cm 超出版心 %.2f cm。" % (sum(widths_cm), tw))
    for r in rows:
        if len(r) != n:
            raise EditError("資料列欄數不符：%r" % (r,))
    t = doc.add_table(rows=1, cols=n)
    t.style = None
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    tblPr = t._tbl.tblPr
    put(tblPr, el("w:tblW", w=sum(_twips(w) for w in widths_cm), type="dxa"))
    bd = el("w:tblBorders")
    for side, pt in (("top", F.table["outerRulePt"]), ("left", 0), ("bottom", F.table["outerRulePt"]),
                     ("right", 0), ("insideH", 0), ("insideV", 0)):
        bd.append(_border("w:" + side, pt))
    put(tblPr, bd)
    mar = el("w:tblCellMar")
    tb, lr = _twips(F.table["cellPaddingTopBottomCm"]), _twips(F.table["cellPaddingLeftRightCm"])
    for side, w in (("top", tb), ("left", lr), ("bottom", tb), ("right", lr)):
        mar.append(el("w:" + side, w=w, type="dxa"))
    put(tblPr, mar)
    for i, w in enumerate(widths_cm):
        t.columns[i].width = Cm(w)
    s_head, s_text = S(doc, "tableHead"), S(doc, "tableText")

    def fill(cell, value, style, header=False):
        cell.width = Cm(widths_cm[cell_index[0]])
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        par = cell.paragraphs[0]
        par.style = style
        txt = "" if value is None else str(value)
        add_runs(par, txt)
        if not header and F.table["numbersAlignRight"] and _NUM.match(txt.strip("* ")):
            par.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        if header:
            tcPr = cell._tc.get_or_add_tcPr()
            tb_ = el("w:tcBorders")
            tb_.append(_border("w:bottom", F.table["headerRulePt"]))
            put(tcPr, tb_)

    cell_index = [0]
    hdr = t.rows[0]
    trPr = hdr._tr.get_or_add_trPr()
    trPr.append(el("w:cantSplit"))
    if F.table["repeatHeaderRow"]:
        trPr.append(el("w:tblHeader"))
    for i, h in enumerate(headers):
        cell_index[0] = i
        fill(hdr.cells[i], h, s_head, header=True)
    for row in rows:
        r = t.add_row()
        r._tr.get_or_add_trPr().append(el("w:cantSplit"))
        for i, v in enumerate(row):
            cell_index[0] = i
            fill(r.cells[i], v, s_text)
    return t


# ════════════════════════════════════════════════════════════════════
# 六、就地編輯：改寫、刪除、換表
# ════════════════════════════════════════════════════════════════════

def _guard(par, action):
    x = par._p
    head = "「%s」" % ptext(x)[:30]
    if has_media(x):
        raise EditError("拒絕%s含圖片的段落%s：圖片是使用者插入的。" % (action, head))
    if x.find(".//" + qn("w:fldChar")) is not None or x.find(".//" + qn("w:fldSimple")) is not None:
        raise EditError("拒絕%s含功能變數的段落%s（目錄、頁碼、交互參照）。" % (action, head))
    if x.find(".//" + qn("w:hyperlink")) is not None:
        raise EditError("拒絕%s含超連結的段落%s；請改為只在段後插入新段落，或請使用者處理。"
                        % (action, head))
    if x.find(".//" + qn("w:footnoteReference")) is not None:
        raise EditError("拒絕%s含註腳的段落%s。" % (action, head))
    if x.find(".//" + qn("w:ins")) is not None or x.find(".//" + qn("w:del")) is not None:
        raise EditError("段落%s含修訂標記，請使用者先接受或拒絕修訂。" % head)


def set_text(par, text, key=None):
    """整段改寫文字（保留段落樣式與使用者的註解錨點）。key 可同時改換樣式。
    內建保護：含圖片、功能變數、超連結、註腳、修訂標記的段落一律拒絕。"""
    _guard(par, "改寫")
    keep = []
    for r in list(par._p.findall(qn("w:r"))):
        if r.find(qn("w:commentReference")) is not None:
            keep.append(r)
        par._p.remove(r)
    if key:
        par.style = S(par.part.document, key)
    add_runs(par, text)
    for r in keep:
        par._p.append(r)
    return par


def delete(doc, first, last=None, allow_tables=False):
    """刪除 first 到 last（含）之間的正文元素。圖片段落與分節段落一律保留並回報；
    範圍內有表格時，除非 allow_tables=True 否則拒絕。回傳摘要 dict。"""
    a = getattr(first, "_element", first)
    b = getattr(last, "_element", last) if last is not None else a
    if a.getparent() is not b.getparent():
        raise EditError("起訖不在同一層級，無法安全刪除。")
    span, cur = [], a
    while cur is not None:
        span.append(cur)
        if cur is b:
            break
        cur = cur.getnext()
    else:
        raise EditError("終點不在起點之後。")
    tables = [e for e in span if e.tag == W_TBL]
    if tables and not allow_tables:
        raise EditError("刪除範圍內有 %d 個表格；確認要刪時請加 allow_tables=True。" % len(tables))
    kept_media, kept_sect, removed = [], 0, 0
    for e in span:
        if e.tag == W_P and has_media(e):
            kept_media.append(ptext(e)[:20] or "（圖片）")
            continue
        if e.tag == W_P and e.find(qn("w:pPr") + "/" + qn("w:sectPr")) is not None:
            kept_sect += 1
            continue
        if e.tag in (W_P, W_TBL):
            e.getparent().remove(e)
            removed += 1
    if kept_media:
        print("【保護】已保留 %d 個圖片段落，未刪除。" % len(kept_media), file=sys.stderr)
    return dict(removed=removed, kept_media=len(kept_media), kept_section_breaks=kept_sect)


def replace_table(doc, caption_par, headers, rows, widths_cm=None, source=None):
    """以新資料取代題注下方的表格（舊表的資料來源段落一併替換），題注保留。"""
    nxt = caption_par._p.getnext()
    if nxt is None or nxt.tag != W_TBL:
        raise EditError("題注「%s」下方不是表格。" % ptext(caption_par._p)[:30])
    after = nxt.getnext()
    src_name = _specs()["source"]["name"]
    if after is not None and after.tag == W_P and Paragraph(after, doc._body).style.name == src_name:
        after.getparent().remove(after)
    nxt.getparent().remove(nxt)
    return Writer(doc, after=caption_par).table(None, headers, rows, widths_cm, source)


# ════════════════════════════════════════════════════════════════════
# 七、圖表重新編號（並同步正文中的「見表 N」）
# ════════════════════════════════════════════════════════════════════

def _labels():
    t = {F.labels["table"], "表"}
    f = {F.labels["figure"], "圖", "图"}
    return t, f


def renumber(doc, fix_refs=True):
    """依出現順序把表題、圖題重新編號（「表 X」也會被編上號），並處理正文引用：
      · 「表〔表題〕」「圖〔圖題〕」→ 換成「表 N」「圖 N」（建議的寫法，不必自己算號碼）；
      · fix_refs=True 時，既有的「見表 3」會隨表號變動同步更新。
    回傳報告 dict；unresolved 為找不到對應表題的引用。"""
    tl, fl = _labels()
    lab = "|".join(sorted(tl | fl, key=len, reverse=True))
    cap_re = re.compile(r"^\s*(%s)\s*(\d+|[XxＸ？?])[\s　]+(.+)$" % lab)
    cap_style = _specs()["caption"]["name"].lower()
    n = {"t": 0, "f": 0}
    remap = {"t": {}, "f": {}}
    titles = {"t": {}, "f": {}}
    captions = set()
    for b in iter_blocks(doc, into_sdt=False):
        if not isinstance(b, Paragraph):
            continue
        txt = ptext(b._p)
        m = cap_re.match(txt)
        if not m:
            continue
        kind = "t" if m.group(1) in tl else "f"
        prev, nxt = b._p.getprevious(), b._p.getnext()
        positioned = (kind == "t" and nxt is not None and nxt.tag == W_TBL) or \
                     (kind == "f" and prev is not None and prev.tag == W_P and has_media(prev))
        if not (positioned or b.style.name.lower() == cap_style):
            continue
        n[kind] += 1
        new = n[kind]
        titles[kind].setdefault(m.group(3).strip(), new)
        old = m.group(2)
        if old.isdigit() and int(old) != new:
            remap[kind][int(old)] = new
        label = F.labels["table"] if kind == "t" else F.labels["figure"]
        want = "%s %d　%s" % (label, new, m.group(3).strip())
        has_field = b._p.find(".//" + qn("w:fldChar")) is not None or \
            b._p.find(".//" + qn("w:fldSimple")) is not None
        if txt != want and not has_field and not has_media(b._p):
            set_text(b, want)  # Word「插入標號」產生的 SEQ 功能變數由 Word 自行編號，不改寫
        captions.add(b._p)
    refs, unresolved = [], []
    # 以表題引用：正文寫「表〔表題〕」，換成「表 N」——agent 不必自己算號碼
    named = re.compile(r"(%s)〔([^〔〕]+)〕" % lab)

    def by_title(m):
        kind = "t" if m.group(1) in tl else "f"
        num = titles[kind].get(m.group(2).strip())
        if num is None:
            unresolved.append(m.group(0))
            return m.group(0)
        label = F.labels["table"] if kind == "t" else F.labels["figure"]
        return "%s %d" % (label, num)

    for p in iter_paragraphs(doc, include_tables=True):
        if p._p in captions:
            continue
        before = ptext(p._p)
        if not named.search(before):
            continue
        for t in p._p.iter(qn("w:t")):
            if t.text and named.search(t.text):
                t.text = named.sub(by_title, t.text)
        after = ptext(p._p)
        if after != before:
            refs.append((before[:40], after[:40]))
    if fix_refs and (remap["t"] or remap["f"]):
        # 只認引用語境（見／如／依…或標點之後），避免改到「代表 3 個」這類詞
        ref_re = re.compile(r"(?<![^見见如依據据按照詳详參参於于在由從从與与和及、，。；：（(「『\s\u3000])"
                            r"(%s)(\s*)(\d+)" % lab)

        def sub(m):
            kind = "t" if m.group(1) in tl else "f"
            num = int(m.group(3))
            return m.group(1) + m.group(2) + str(remap[kind].get(num, num))

        for p in iter_paragraphs(doc, include_tables=True):
            if p._p in captions:
                continue
            before = ptext(p._p)
            if not ref_re.search(before):
                continue
            for t in p._p.iter(qn("w:t")):
                if t.text and ref_re.search(t.text):
                    t.text = ref_re.sub(sub, t.text)
            after = ptext(p._p)
            if after != before:
                refs.append((before[:40], after[:40]))
    return dict(tables=n["t"], figures=n["f"], remap=remap, refs=refs, unresolved=unresolved)


# ════════════════════════════════════════════════════════════════════
# 八、目錄功能變數定位（docx_dump 與 reset_toc 共用）
# ════════════════════════════════════════════════════════════════════

def find_toc_span(doc):
    """回傳 (起始段落元素, 結束段落元素)；以 TOC 功能變數本身定位，不依賴樣式名稱
    （中文版 Word 存檔後目錄樣式 ID 會變成數字，靠樣式找會失效）。"""
    depth, toc_depth, begin_p, start = 0, None, None, None
    for p in doc.element.body.iter(W_P):
        fs = p.find(".//" + qn("w:fldSimple"))
        if toc_depth is None and fs is not None and re.match(r"\s*TOC\b", fs.get(qn("w:instr")) or ""):
            return p, p
        for e in p.iter(qn("w:fldChar"), qn("w:instrText")):
            if e.tag == qn("w:fldChar"):
                kind = e.get(qn("w:fldCharType"))
                if kind == "begin":
                    depth += 1
                    begin_p = p
                elif kind == "end":
                    if toc_depth is not None and depth == toc_depth:
                        return start, p
                    depth -= 1
            elif toc_depth is None and re.match(r"\s*TOC\b", e.text or ""):
                toc_depth, start = depth, begin_p
    if start is not None:
        return start, start
    return None


# ════════════════════════════════════════════════════════════════════
# 九、有效格式解析（檢查與歸一共用）：直接格式 → 樣式鏈 → 文件預設
# ════════════════════════════════════════════════════════════════════

_THEME_OF = {"eastAsia": "eastAsiaTheme", "ascii": "asciiTheme", "hAnsi": "hAnsiTheme", "cs": "cstheme"}


class Resolver:
    """依 Word 的繼承規則算出段落／run 的實際字型、行距等。"""

    def __init__(self, doc):
        st = doc.styles.element
        self.styles = {s.get(qn("w:styleId")): s for s in st.findall(qn("w:style"))}
        self.default_p = next((sid for sid, s in self.styles.items()
                               if s.get(qn("w:type")) == "paragraph"
                               and s.get(qn("w:default")) in ("1", "true")), "Normal")
        dd = st.find(qn("w:docDefaults"))
        self.rdef = dd.find(qn("w:rPrDefault") + "/" + qn("w:rPr")) if dd is not None else None
        self.pdef = dd.find(qn("w:pPrDefault") + "/" + qn("w:pPr")) if dd is not None else None

    def chain(self, sid):
        out, seen = [], set()
        while sid and sid in self.styles and sid not in seen:
            seen.add(sid)
            s = self.styles[sid]
            out.append(s)
            b = s.find(qn("w:basedOn"))
            sid = b.get(qn("w:val")) if b is not None else None
        return out

    def pstyle_id(self, p_el):
        ps = p_el.find(qn("w:pPr") + "/" + qn("w:pStyle"))
        return ps.get(qn("w:val")) if ps is not None else self.default_p

    def name(self, sid):
        s = self.styles.get(sid)
        n = s.find(qn("w:name")) if s is not None else None
        return n.get(qn("w:val")) if n is not None else (sid or "")

    def style_id_by_name(self, name):
        low = name.lower()
        for sid in self.styles:
            if self.name(sid).lower() == low:
                return sid
        return None

    def p_levels(self, p_el):
        lv = [p_el.find(qn("w:pPr"))]
        lv += [s.find(qn("w:pPr")) for s in self.chain(self.pstyle_id(p_el))]
        lv.append(self.pdef)
        return [x for x in lv if x is not None]

    def r_levels(self, r_el, p_el):
        rPr = r_el.find(qn("w:rPr")) if r_el is not None else None
        lv = [rPr]
        if rPr is not None and rPr.find(qn("w:rStyle")) is not None:
            lv += [s.find(qn("w:rPr")) for s in self.chain(rPr.find(qn("w:rStyle")).get(qn("w:val")))]
        lv += [s.find(qn("w:rPr")) for s in self.chain(self.pstyle_id(p_el))]
        lv.append(self.rdef)
        return [x for x in lv if x is not None]

    def spacing(self, p_el):
        """回傳 (行距值 twips, 規則 auto/exact/atLeast)。"""
        for pPr in self.p_levels(p_el):
            sp = pPr.find(qn("w:spacing"))
            if sp is not None and sp.get(qn("w:line")) is not None:
                return int(sp.get(qn("w:line"))), sp.get(qn("w:lineRule")) or "auto"
        return 240, "auto"

    def font(self, r_el, p_el, which="eastAsia"):
        """回傳 (字型名稱, 是否為主題字型)。同一層同時有主題屬性時，主題字型優先（Word 行為）。"""
        for rPr in self.r_levels(r_el, p_el):
            rf = rPr.find(qn("w:rFonts"))
            if rf is None:
                continue
            th = rf.get(qn("w:" + _THEME_OF[which]))
            if th:
                return th, True
            v = rf.get(qn("w:" + which))
            if v:
                return v, False
        return None, False

    def r_flag(self, r_el, p_el, tag):
        for rPr in self.r_levels(r_el, p_el):
            e = rPr.find(qn(tag))
            if e is not None:
                v = e.get(qn("w:val"))
                return v not in ("0", "false", "off", "none")
        return False

    def p_flag(self, p_el, tag):
        for pPr in self.p_levels(p_el):
            e = pPr.find(qn(tag))
            if e is not None:
                return e.get(qn("w:val")) not in ("0", "false", "off")
        return False


def _toc_members(doc):
    """目錄功能變數範圍內的段落元素集合。"""
    span = find_toc_span(doc)
    out = set()
    if span:
        cur = span[0]
        while cur is not None:
            out.add(cur)
            if cur is span[1]:
                break
            cur = cur.getnext()
    return out
