# -*- coding: utf-8 -*-
"""發佈前檢查：14 項排版檢查（計入通過率）＋ 內容提醒（不計入）。

每個未通過項都會列出位置（所屬章節＋段首文字），方便先定位、再判斷是工具造成
還是使用者手填的內容。所有標準值讀自 format.json。

用法：
  python check_doc.py 文件.docx              # 草稿模式：修訂標記與註解只提醒
  python check_doc.py 文件.docx --release    # 發佈模式：修訂標記與註解視為未通過
  python check_doc.py 文件.docx --json       # 機器可讀輸出
離開碼：全部通過為 0，否則為 1。
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import docxkit as K  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402
from docx.table import Table  # noqa: E402
from docx.text.paragraph import Paragraph  # noqa: E402

TWIPS_PER_PT = 20
H_PAT = re.compile(r"^(?:[一二三四五六七八九十]+、|（[一二三四五六七八九十]+）|\d+\.\s?\S|\d+\.\d+)")
EMOJI = re.compile("[\U0001F300-\U0001FAFF☀-➿⭐⭕✅❌]")
HALF_PUNCT = re.compile(r"[一-鿿][,;:!?][一-鿿\s]|[一-鿿]\([^)]*\)")
H_NUM = [re.compile(r"^[一二三四五六七八九十]+、"), re.compile(r"^（[一二三四五六七八九十]+）"),
         re.compile(r"^\d+\.")]


class Report:
    def __init__(self, release):
        self.release = release
        self.items = []
        self.warnings = []

    def add(self, no, name, ok, detail="", locs=(), soft=False):
        status = "pass" if ok else ("warn" if soft else "fail")
        self.items.append(dict(no=no, name=name, status=status, detail=detail, locations=list(locs)[:6],
                               more=max(0, len(list(locs)) - 6)))

    def warn(self, name, locs):
        if locs:
            self.warnings.append(dict(name=name, count=len(locs), locations=list(locs)[:5]))


def excerpt(t, n=24):
    t = t.strip().replace("\n", " ")
    return t[:n] + ("…" if len(t) > n else "")


def run_checks(path, release=False):
    doc = K.open_document(path, quiet=True)
    R = K.Resolver(doc)
    sp = K._specs()
    rep = Report(release)
    f = K.F
    name_key = {v["name"].lower(): k for k, v in sp.items() if not k.startswith("_")}

    def key_of(p_el):
        return name_key.get(R.name(R.pstyle_id(p_el)).lower())

    # ---- 掃描正文：段落位置、章節、所屬節 ----
    toc = K.find_toc_span(doc)
    toc_set = set()
    if toc:
        cur = toc[0]
        while cur is not None:
            toc_set.add(cur)
            if cur is toc[1]:
                break
            cur = cur.getnext()
    entries, heading, sec = [], "（文件開頭）", 0
    for blk in K.iter_blocks(doc):
        e = blk._element
        if isinstance(blk, Paragraph):
            k = key_of(e)
            txt = K.ptext(e)
            if k in ("h1", "h2", "h3") and txt.strip():
                heading = excerpt(txt, 18)
            entries.append(dict(kind="p", el=e, par=blk, key=k, text=txt, sec=sec, head=heading,
                                toc=e in toc_set, media=K.has_media(e),
                                sect=e.find(qn("w:pPr") + "/" + qn("w:sectPr")) is not None))
            if entries[-1]["sect"]:
                sec += 1
        else:
            entries.append(dict(kind="t", el=e, tbl=blk, sec=sec, head=heading))
    nsec = len(doc.sections)

    def loc(en, extra=""):
        place = "封面／目錄" if (nsec > 1 and en["sec"] == 0) else en["head"]
        t = en.get("text", "")
        what = excerpt(t) if t.strip() else ("（圖片）" if en.get("media") else "（空段）")
        return "〔%s〕「%s」%s" % (place, what, extra)

    paras = [e for e in entries if e["kind"] == "p"]
    body = [e for e in paras if not e["toc"]]

    # 1 字型
    bad = defaultdict(list)
    allowed_e = {f.fonts["body"], f.fonts["heading"], f.fonts["quote"]}
    allowed_l = {f.fonts["latin"], f.fonts["code"]}

    def scan_runs(p_el, where):
        for r in p_el.iter(qn("w:r")):
            if not any((t.text or "").strip() for t in r.findall(qn("w:t"))):
                continue
            ea, th1 = R.font(r, p_el, "eastAsia")
            la, th2 = R.font(r, p_el, "ascii")
            for name, th, ok_set in ((ea, th1, allowed_e), (la, th2, allowed_l)):
                if th:
                    bad["主題字型 " + name].append(where)
                elif name and name not in ok_set:
                    bad[name].append(where)

    for en in paras:
        scan_runs(en["el"], loc(en))
    for en in entries:
        if en["kind"] == "t":
            for p in en["el"].iter(qn("w:p")):
                scan_runs(p, "〔%s〕表格內「%s」" % (en["head"], excerpt(K.ptext(p))))
    for rel in doc.part.rels.values():
        if not rel.is_external and rel.reltype.endswith(("/header", "/footer")):
            for p in rel.target_part.element.iter(qn("w:p")):
                scan_runs(p, "頁首頁尾「%s」" % excerpt(K.ptext(p)))
    locs = [("%s：%s" % (k, v[0])) + ("（另 %d 處）" % (len(v) - 1) if len(v) > 1 else "")
            for k, v in bad.items()]
    rep.add(1, "字型僅限規範字型（%s／%s／%s＋%s）" % (f.fonts["body"], f.fonts["heading"],
                                                   f.fonts["quote"], f.fonts["latin"]),
            not bad, "越界：%s" % "、".join(bad) if bad else "", locs)

    # 2 標題來自樣式、層級連續、不超過上限
    manual, jump, deep = [], [], []
    last = 0
    for en in body:
        t = en["text"].strip()
        if not t:
            continue
        sname = R.name(R.pstyle_id(en["el"])).lower()
        lvl = int(en["key"][1]) if en["key"] in ("h1", "h2", "h3") else (
            int(sname.split()[-1]) if sname.startswith("heading") and sname.split()[-1].isdigit() else 0)
        if lvl:
            if lvl > f.headings["maxLevel"]:
                deep.append(loc(en))
            if lvl > last + 1 and en["sec"] >= (1 if nsec > 1 else 0):
                jump.append(loc(en, "（第 %d 級接在第 %d 級後）" % (lvl, last)))
            last = lvl
        elif en["key"] in (None, "normal") and H_PAT.match(t) and len(t) <= 40 and t[-1] not in "。；：;:":
            manual.append(loc(en))
    rep.add(2, "標題均套用標題樣式、層級連續、不超過 %d 級" % f.headings["maxLevel"],
            not (manual or jump or deep),
            "疑似手打標題 %d、跳級 %d、超過層級 %d" % (len(manual), len(jump), len(deep))
            if (manual or jump or deep) else "", manual + jump + deep)

    # 3 行距
    exp = {"normal": f.line["body"], "quote": f.line["body"], "callout": f.line["body"],
           "subtitle": f.line["body"], "meta": f.line["body"], "toc1": f.line["body"],
           "toc2": f.line["body"], "toc3": f.line["body"], "h1": f.line["h1"], "h2": f.line["h2"],
           "h3": f.line["h3"], "title": f.line["title"], "tocTitle": f.line["h1"],
           "caption": f.line["caption"], "source": f.line["caption"], "code": f.line["code"]}
    wrong = []
    for en in body:
        if en["media"] or not en["text"].strip():
            continue
        want = exp.get(en["key"], f.line["body"])
        line, rule = R.spacing(en["el"])
        if rule != "exact" or abs(line - want * TWIPS_PER_PT) > 1:
            got = "%g 磅固定" % (line / 20) if rule == "exact" else ("%s 倍" % round(line / 240, 2)
                                                                     if rule == "auto" else "最小 %g 磅" % (line / 20))
            wrong.append(loc(en, "（%s，應為 %g 磅固定）" % (got, want)))
    rep.add(3, "行距為固定行高（正文 %g 磅）" % f.line["body"], not wrong,
            "不符 %d 段" % len(wrong) if wrong else "", wrong)

    # 4 空行、空格縮排
    empty, spaces = [], []
    for en in body:
        e = en["el"]
        if en["key"] == "code":
            continue
        if not en["text"].strip():
            if en["media"] or en["sect"] or e.find(".//" + qn("w:fldChar")) is not None \
                    or e.find(".//" + qn("w:br")) is not None:
                continue
            empty.append(loc(en))
        elif re.match(r"^(　|\s{2,}|\t)", en["text"]):
            spaces.append(loc(en))
    rep.add(4, "無空行排版、無空格縮排", not (empty or spaces),
            "空段 %d、空格縮排 %d" % (len(empty), len(spaces)) if (empty or spaces) else "",
            empty + spaces)

    # 5 三線表、重複標題列、表寬
    def sec_tw(i):  # 表格所在節的版心寬度（twips）
        s_ = doc.sections[min(i, nsec - 1)]
        return int((s_.page_width - s_.left_margin - s_.right_margin) / 635)
    tables = [e for e in entries if e["kind"] == "t"]
    tbad = []

    def bval(borders, side):
        x = borders.find(qn("w:" + side)) if borders is not None else None
        return None if x is None else x.get(qn("w:val"))

    for i, en in enumerate(tables, 1):
        tbl = en["el"]
        tblPr = tbl.find(qn("w:tblPr"))
        b = tblPr.find(qn("w:tblBorders")) if tblPr is not None else None
        sb = None
        ts = tblPr.find(qn("w:tblStyle")) if tblPr is not None else None
        if ts is not None and ts.get(qn("w:val")) in R.styles:
            sb = R.styles[ts.get(qn("w:val"))].find(".//" + qn("w:tblBorders"))
        val = lambda s: bval(b, s) or bval(sb, s) or "none"  # noqa: E731
        # 有些編輯器（如 LibreOffice）把框線寫在每個儲存格上，需一併判斷
        trs = tbl.findall(qn("w:tr"))

        def row_has(tr, side):
            tcs = tr.findall(qn("w:tc"))
            return bool(tcs) and all(bval(tc.find(qn("w:tcPr") + "/" + qn("w:tcBorders")), side)
                                     not in (None, "none", "nil") for tc in tcs)
        top_ok = val("top") not in ("none", "nil") or (trs and row_has(trs[0], "top"))
        bot_ok = val("bottom") not in ("none", "nil") or (trs and row_has(trs[-1], "bottom"))
        why = []
        if not (top_ok and bot_ok):
            why.append("缺頂線或底線")
        if any(row_has(tr, "bottom") for tr in trs[1:-1]):
            why.append("有橫向格線")
        if any(val(s) not in ("none", "nil") for s in ("left", "right", "insideH", "insideV")):
            why.append("有框線或格線")
        for tc in tbl.iter(qn("w:tcBorders")):
            if any(bval(tc, s) not in (None, "none", "nil") for s in ("left", "right", "insideV")):
                why.append("儲存格有直線")
                break
        tr = tbl.find(qn("w:tr"))
        if tr is None or tr.find(qn("w:trPr") + "/" + qn("w:tblHeader")) is None:
            why.append("標題列未設跨頁重複")
        width = sum(int(g.get(qn("w:w")) or 0) for g in tbl.iter(qn("w:gridCol")))
        if width > sec_tw(en["sec"]) + 30:
            why.append("表寬 %.1f cm 超出版心" % (width / 1440 * 2.54))
        if why:
            tbad.append("〔%s〕第 %d 個表格：%s" % (en["head"], i, "、".join(why)))
    rep.add(5, "表格為三線表、標題列跨頁重複、不超出版心", not tbad,
            "%d / %d 個表格不符" % (len(tbad), len(tables)) if tbad else "共 %d 個表格" % len(tables), tbad)

    # 6 題注：表題在上、圖題在下、編號連續
    tl = {f.labels["table"], "表"}
    fl = {f.labels["figure"], "圖", "图"}
    cap_re = re.compile(r"^\s*(%s)\s*(\d+)[\s　]+\S" % "|".join(tl | fl))
    first_body_sec = 1 if nsec > 1 else 0
    cbad, tn, fn = [], [], []
    for idx, en in enumerate(entries):
        if en["sec"] < first_body_sec:
            continue
        if en["kind"] == "t":
            prev = entries[idx - 1] if idx else None
            m = cap_re.match(prev["text"]) if prev and prev["kind"] == "p" else None
            if not m or m.group(1) not in tl:
                cbad.append("〔%s〕表格上方缺少「%s N　表題」" % (en["head"], f.labels["table"]))
            else:
                tn.append(int(m.group(2)))
        elif en["media"] and en["el"].getparent().tag == qn("w:body"):
            nxt = entries[idx + 1] if idx + 1 < len(entries) else None
            m = cap_re.match(nxt["text"]) if nxt and nxt["kind"] == "p" else None
            if not m or m.group(1) not in fl:
                cbad.append(loc(en, "圖片下方缺少「%s N　圖題」" % f.labels["figure"]))
            else:
                fn.append(int(m.group(2)))
    named = re.compile(r"(%s)〔[^〔〕]+〕" % "|".join(tl | fl))
    for en in body:
        mm = named.search(en["text"])
        if mm:
            cbad.append(loc(en, "（未解析的引用「%s」，請執行 finish.py 或修正表題）" % mm.group(0)))
    if tn != list(range(1, len(tn) + 1)):
        cbad.append("表號不連續：%s" % tn)
    if fn != list(range(1, len(fn) + 1)):
        cbad.append("圖號不連續：%s" % fn)
    rep.add(6, "表題在上、圖題在下、編號連續", not cbad,
            "表 %d、圖 %d" % (len(tn), len(fn)) if not cbad else "%d 項問題" % len(cbad), cbad)

    # 7 遺留字串控制、標題與下段同頁
    def style_flag(name, tag):
        sid = R.style_id_by_name(name)
        for s in R.chain(sid):
            x = s.find(qn("w:pPr") + "/" + qn(tag))
            if x is not None:
                return x.get(qn("w:val")) not in ("0", "false", "off")
        return False
    wc_off = False
    sid = R.style_id_by_name("Normal")
    for s in R.chain(sid):
        x = s.find(qn("w:pPr") + "/" + qn("w:widowControl"))
        if x is not None:
            wc_off = x.get(qn("w:val")) in ("0", "false", "off")
            break
    kn = [h for h in ("Heading 1", "Heading 2", "Heading 3") if not style_flag(h, "w:keepNext")]
    rep.add(7, "遺留字串控制開啟、標題與下段同頁", not wc_off and not kn,
            ("內文關閉了遺留字串控制 " if wc_off else "") + ("未設與下段同頁：%s" % kn if kn else ""))

    # 8 頁碼與分節
    def has_page(section):
        ft = section.footer
        if ft.is_linked_to_previous:
            return None
        return any("PAGE" in (t.text or "") for t in ft._element.iter(qn("w:instrText"))) or \
            any("PAGE" in (x.get(qn("w:instr")) or "") for x in ft._element.iter(qn("w:fldSimple")))
    secs = doc.sections
    why = []
    if len(secs) == 1:
        if not has_page(secs[0]):
            why.append("頁尾沒有頁碼")
    else:
        if has_page(secs[0]):
            why.append("封面／目錄節顯示了頁碼")
        pg = secs[1]._sectPr.find(qn("w:pgNumType"))
        if pg is None or pg.get(qn("w:start")) != "1":
            why.append("正文節頁碼未從 1 起編")
        if not has_page(secs[1]):
            why.append("正文節頁尾沒有頁碼")
    rep.add(8, "頁碼自正文首頁起編、封面不顯示頁碼", not why, "、".join(why))

    # 9 顏色
    ok_c = {f.color["text"], f.color["title"], f.color["aux"], f.color["header"], "auto"}
    ok_fill = {f.color["shade"], f.code_theme["background"], "auto", "FFFFFF"}
    for th in f.code["themes"].values():
        ok_fill.add(th["background"])
    cb = []
    for en in body:
        if en["key"] == "code":
            continue
        pshd = en["el"].find(qn("w:pPr") + "/" + qn("w:shd"))
        if pshd is not None and (pshd.get(qn("w:fill")) or "auto").upper() not in ok_fill:
            cb.append(loc(en, "（段落底色 %s）" % pshd.get(qn("w:fill"))))
        for r in en["el"].iter(qn("w:r")):
            if not "".join(t.text or "" for t in r.findall(qn("w:t"))).strip():
                continue
            c = None
            for rPr in R.r_levels(r, en["el"]):
                x = rPr.find(qn("w:color"))
                if x is not None:
                    c = "主題色" if x.get(qn("w:themeColor")) else (x.get(qn("w:val")) or "auto").upper()
                    break
            if c and c not in ok_c:
                cb.append(loc(en, "（文字顏色 %s）" % c))
                break
            rPr = r.find(qn("w:rPr"))
            if rPr is not None and rPr.find(qn("w:highlight")) is not None:
                cb.append(loc(en, "（螢光標記）"))
                break
            rs = rPr.find(qn("w:shd")) if rPr is not None else None
            if rs is not None and (rs.get(qn("w:fill")) or "auto").upper() not in ("AUTO",):
                cb.append(loc(en, "（文字底色）"))
                break
    rep.add(9, "顏色在規範內（黑白列印層次清楚）", not cb, "%d 處越界" % len(cb) if cb else "", cb)

    # 10 頁面與邊界
    p = f.page
    pb = []
    for i, s in enumerate(secs, 1):
        w, h = sorted([s.page_width.cm, s.page_height.cm])
        why = []
        if abs(w - p["widthCm"]) > .05 or abs(h - p["heightCm"]) > .05:
            why.append("紙張 %.1f×%.1f" % (w, h))
        for attr, k in (("top_margin", "marginTopCm"), ("bottom_margin", "marginBottomCm"),
                        ("left_margin", "marginLeftCm"), ("right_margin", "marginRightCm"),
                        ("header_distance", "headerCm"), ("footer_distance", "footerCm")):
            v = getattr(s, attr)
            if v is None or abs(v.cm - p[k]) > .02:
                why.append("%s=%s" % (k, "未設" if v is None else "%.2f" % v.cm))
        if why:
            pb.append("第 %d 節：%s" % (i, "、".join(why)))
    rep.add(10, "紙張 %s、邊界上下 %g／左右 %g cm" % (p["size"], p["marginTopCm"], p["marginLeftCm"]),
            not pb, "", pb)

    # 11 目錄
    nh = sum(1 for en in body if en["key"] in ("h1", "h2"))
    rep.add(11, "目錄以 TOC 功能變數產生", toc is not None or nh <= 3,
            "" if toc else ("短文件（%d 個標題），可不設目錄" % nh if nh <= 3 else "找不到目錄功能變數"))

    # 12 修訂標記與註解
    ins, dele = K.tracked_changes(doc)
    cms = K.read_comments(doc)
    clean = not (ins or dele or cms)
    rep.add(12, "無修訂標記、無註解（發佈前須清除）", clean,
            "" if clean else "修訂：插入 %d、刪除 %d；註解 %d 則" % (ins, dele, len(cms)),
            ["註解 #%s %s：%s" % (c[0], c[1], excerpt(c[2], 30)) for c in cms], soft=not release)

    # 13 強調方式：只用粗體，且不整段加粗
    eb = []
    for en in body:
        if en["key"] in ("code", "h1", "h2", "h3", "title", "tocTitle", "caption") or not en["text"].strip():
            continue
        total = bold = 0
        flagged = False
        for r in en["el"].iter(qn("w:r")):
            t = "".join(x.text or "" for x in r.findall(qn("w:t")))
            if not t.strip():
                continue
            total += len(t)
            if R.r_flag(r, en["el"], "w:b"):
                bold += len(t)
            for tag, label in (("w:i", "斜體"), ("w:u", "底線"), ("w:strike", "刪除線")):
                if not flagged and R.r_flag(r, en["el"], tag):
                    eb.append(loc(en, "（%s）" % label))
                    flagged = True
        if not flagged and total > 20 and bold / total > f.content["maxBoldRatio"]:
            eb.append(loc(en, "（整段加粗 %d%%）" % (bold * 100 // total)))
    rep.add(13, "強調只用粗體引導句，不用斜體、底線、整段加粗", not eb,
            "%d 處" % len(eb) if eb else "", eb)

    # 14 圖片段落不得用固定行高（會被裁切）
    clip = []
    for en in paras:
        if en["media"]:
            line, rule = R.spacing(en["el"])
            if rule == "exact":
                clip.append(loc(en, "（固定 %g 磅，圖片會被裁切）" % (line / 20)))
    for en in tables:
        for pe in en["el"].iter(qn("w:p")):
            if K.has_media(pe) and R.spacing(pe)[1] == "exact":
                clip.append("〔%s〕表格內圖片（固定行高，會被裁切）" % en["head"])
    rep.add(14, "圖片段落為單行間距（不被裁切）", not clip, "%d 處" % len(clip) if clip else "", clip)

    # ---- 內容提醒（不影響通過率）----
    c = f.content
    longp, vague, marks, half, emo, hdot, hnum = [], [], [], [], [], [], []
    for en in body:
        t = en["text"].strip()
        if not t or en["key"] == "code":
            continue
        if en["key"] in ("normal", None) and len(t) > c["maxParagraphChars"]:
            longp.append(loc(en, "（%d 字）" % len(t)))
        for w in c["vagueWords"]:
            if w in t:
                vague.append(loc(en, "（「%s」）" % w))
                break
        for w in c["openMarkers"]:
            if w in t:
                marks.append(loc(en, "（%s）" % w))
                break
        if HALF_PUNCT.search(t):
            half.append(loc(en))
        if EMOJI.search(t):
            emo.append(loc(en))
        if en["key"] in ("h1", "h2", "h3"):
            if t[-1] in "。.":
                hdot.append(loc(en))
            lv = int(en["key"][1])
            if lv <= len(H_NUM) and not H_NUM[lv - 1].match(t) and en["sec"] >= first_body_sec:
                hnum.append(loc(en, "（第 %d 級應以「%s」編號）" % (lv, f.headings["numbering"][lv - 1])))
    for en in entries:
        if en["kind"] == "t":
            for pe in en["el"].iter(qn("w:p")):
                t = K.ptext(pe)
                for w in c["openMarkers"]:
                    if w in t:
                        marks.append("〔%s〕表格內「%s」（%s）" % (en["head"], excerpt(t), w))
                        break
    rep.warn("待辦標記（待拍板／待補等，發佈前須清空）", marks)
    rep.warn("段落過長（超過 %d 字，建議拆段或改表格）" % c["maxParagraphChars"], longp)
    rep.warn("不可判定的模糊用語（改為具體條件或數字）", vague)
    rep.warn("中文間夾半形標點（改用全形）", half)
    rep.warn("出現表情符號", emo)
    rep.warn("標題以句號結尾", hdot)
    rep.warn("標題編號與層級不符", hnum)
    return rep


def render(rep, path, as_json=False):
    passed = sum(1 for i in rep.items if i["status"] == "pass")
    total = len(rep.items)
    fails = sum(1 for i in rep.items if i["status"] == "fail")
    if as_json:
        return json.dumps(dict(file=str(path), profile=K.F.profile, release=rep.release, passed=passed,
                               total=total, failed=fails, items=rep.items, warnings=rep.warnings),
                          ensure_ascii=False, indent=2)
    out = ["排版檢查　%s　（format.json · %s · %s）" % (Path(path).name, K.F.profile,
                                                   "發佈模式" if rep.release else "草稿模式"),
           "─" * 48]
    mark = {"pass": "通過", "fail": "未過", "warn": "提醒"}
    for i in rep.items:
        out.append("%2d %s  %s%s" % (i["no"], mark[i["status"]], i["name"],
                                     ("　→ " + i["detail"]) if i["detail"] else ""))
        if i["status"] != "pass":
            for l_ in i["locations"]:
                out.append("        · " + l_)
            if i["more"]:
                out.append("        · ……另 %d 處" % i["more"])
    if rep.warnings:
        out.append("")
        out.append("內容提醒（不影響通過率）")
        for w in rep.warnings:
            out.append("  ‣ %s：%d 處" % (w["name"], w["count"]))
            for l_ in w["locations"]:
                out.append("        · " + l_)
    out.append("")
    out.append("結果：通過 %d / %d%s" % (passed, total,
               "。未通過項請先定位到段落，再判斷是工具造成還是使用者手填的內容；"
               "屬於使用者內容的，列出位置與影響請使用者決定。" if fails else "。"))
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description="Word 正式文件發佈前檢查")
    ap.add_argument("docx")
    ap.add_argument("--release", action="store_true", help="發佈模式：修訂標記與註解視為未通過")
    ap.add_argument("--json", action="store_true", help="輸出 JSON")
    a = ap.parse_args()
    rep = run_checks(a.docx, a.release)
    print(render(rep, a.docx, a.json))
    sys.exit(0 if all(i["status"] != "fail" for i in rep.items) else 1)


if __name__ == "__main__":
    main()
