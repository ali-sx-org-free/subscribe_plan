# -*- coding: utf-8 -*-
"""重建目錄功能變數：清掉過期的目錄內容與孤兒 _Toc 書籤，換上標記「待更新」的 TOC
功能變數，並設定開檔時更新功能變數，讓 Word 開啟時自動重算目錄。

改過標題（新增、刪除、改名、調整順序）後一定要執行，否則目錄條目會指向已不存在的
書籤，點了不會跳轉。finish.py 每輪都會自動執行。

定位方式：直接找 TOC 功能變數本身（含 Word「參考資料 › 目錄」插入的內容控制項），
不依賴樣式名稱——中文版 Word 存檔後目錄樣式 ID 會變成數字，靠樣式找會失效。
若目錄最後一段同時帶著分節符號，分節設定會移到新目錄段落上，不會遺失。

用法：python reset_toc.py 文件.docx
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import docxkit as K  # noqa: E402
from docx.oxml import OxmlElement  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402
from docx.shared import Pt  # noqa: E402
from docx.text.paragraph import Paragraph  # noqa: E402


def reset(doc):
    span = K.find_toc_span(doc)
    if span is None:
        return None
    a, b = span
    if b.getparent() is not a.getparent():
        b = a
    els, cur = [], a
    while cur is not None:
        els.append(cur)
        if cur is b:
            break
        cur = cur.getnext()
    new = OxmlElement("w:p")
    a.addprevious(new)
    par = Paragraph(new, doc._body)
    par.paragraph_format.first_line_indent = Pt(0)
    sect = None
    for e in els:
        s = e.find(qn("w:pPr") + "/" + qn("w:sectPr"))
        if s is not None:
            sect = s
    if sect is not None:
        K.put(new.get_or_add_pPr(), sect)
    K._toc_field(new)
    for e in els:
        e.getparent().remove(e)
    ids = set()
    body = doc.element.body
    for bs in list(body.iter(qn("w:bookmarkStart"))):
        if (bs.get(qn("w:name")) or "").startswith("_Toc"):
            ids.add(bs.get(qn("w:id")))
            bs.getparent().remove(bs)
    for be in list(body.iter(qn("w:bookmarkEnd"))):
        if be.get(qn("w:id")) in ids:
            be.getparent().remove(be)
    K._setup_settings(doc)
    return dict(removed=len(els), bookmarks=len(ids), kept_section=sect is not None)


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    doc = K.open_document(sys.argv[1], quiet=True)
    r = reset(doc)
    if r is None:
        print("未找到目錄功能變數，未做任何修改。（文件沒有目錄時可忽略）")
        sys.exit(1)
    doc.save(sys.argv[1])
    print("目錄已重建：清除舊目錄 %d 段、_Toc 書籤 %d 個%s；Word 開檔時會自動更新。"
          % (r["removed"], r["bookmarks"], "，分節設定已保留" if r["kept_section"] else ""))


if __name__ == "__main__":
    main()
