# -*- coding: utf-8 -*-
"""由 docs/*.md 與 AGENTS.md 產生 Portal 內容 assets/content.js（index.html 讀取它）。

改了指引文字後執行一次：python scripts/build_portal.py
不需要任何第三方套件；只支援本包用到的 Markdown 語法：
  # 群組名稱 ／ ## 頁面（Portal 左側選單一頁）／ ### #### 小標
  段落、**粗體**、`程式碼`、[連結](網址)、- 清單、1. 編號清單（可內縮一層）、- [ ] 核取項目
  表格、``` 程式碼區塊、> 說明框（> [!warn] 為提醒框）
控制註解（Markdown 閱讀時不顯示）：
  <!-- group: id · EN -->  <!-- id: 頁面代號 -->  <!-- include: 相對路徑 -->
  <!-- preview: 名稱 -->（由 guide.js 畫出示意圖）  <!-- copy -->（下一個程式碼區塊加複製鈕）
  <!-- checklist -->（下一個清單變成可勾選的檢查清單）
頁面標題下第一個「> 」段落作為頁面摘要。
"""
from __future__ import annotations

import html
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIRECTIVE = re.compile(r"^<!--\s*(\w+)\s*:?\s*(.*?)\s*-->$")


def inline(text):
    """行內語法：先跳脫 HTML，再處理 `code`、**粗體**、[連結](網址)。"""
    parts = re.split(r"(`[^`]+`)", text)
    out = []
    for part in parts:
        if part.startswith("`") and part.endswith("`") and len(part) > 1:
            out.append("<code>%s</code>" % html.escape(part[1:-1]))
            continue
        s = html.escape(part, quote=False)
        s = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", s)
        s = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)",
                   lambda m: '<a href="%s">%s</a>' % (html.escape(m.group(2)), m.group(1)), s)
        out.append(s)
    return "".join(out)


def md_to_html(lines, shift=1):
    """把一段 Markdown 轉成 HTML。shift：標題降級數（### → h2 時 shift=1）。"""
    out, i, n = [], 0, len(lines)
    pending = {"copy": False, "checklist": False}
    para = []

    def flush():
        if para:
            out.append("<p>%s</p>" % inline(" ".join(x.strip() for x in para)))
            para.clear()

    while i < n:
        line = lines[i].rstrip("\n")
        s = line.strip()
        d = DIRECTIVE.match(s)
        if d:
            flush()
            key, val = d.group(1), d.group(2)
            if key == "preview":
                out.append('<div class="preview" data-preview="%s"></div>' % html.escape(val))
            elif key in ("copy", "checklist"):
                pending[key] = True
            i += 1
            continue
        if s.startswith("<!--"):
            i += 1
            continue
        if not s:
            flush()
            i += 1
            continue
        m = re.match(r"^(#{2,5})\s+(.*)$", s)
        if m:
            flush()
            lv = min(len(m.group(1)) - shift, 4)
            out.append("<h%d>%s</h%d>" % (lv, inline(m.group(2)), lv))
            i += 1
            continue
        if s.startswith("```"):
            flush()
            j = i + 1
            buf = []
            while j < n and not lines[j].strip().startswith("```"):
                buf.append(lines[j].rstrip("\n"))
                j += 1
            cls = "source copyable" if pending["copy"] else "source"
            pending["copy"] = False
            out.append('<pre class="%s"><code>%s</code></pre>' % (cls, html.escape("\n".join(buf))))
            i = j + 1
            continue
        if s.startswith("|") and i + 1 < n and re.match(r"^\|?\s*:?-{2,}", lines[i + 1].strip()):
            flush()
            rows = []
            j = i
            while j < n and lines[j].strip().startswith("|"):
                rows.append(lines[j].strip())
                j += 1

            def cells(r):
                r = r.strip().strip("|")
                return [c.strip() for c in re.split(r"(?<!\\)\|", r)]
            head = cells(rows[0])
            body = [cells(r) for r in rows[2:]]
            t = ['<div class="table-scroll"><table class="doc-table"><thead><tr>']
            t += ["<th>%s</th>" % inline(c) for c in head]
            t.append("</tr></thead><tbody>")
            for r in body:
                t.append("<tr>" + "".join("<td>%s</td>" % inline(c) for c in r) + "</tr>")
            t.append("</tbody></table></div>")
            out.append("".join(t))
            i = j
            continue
        if s.startswith(">"):
            flush()
            buf = []
            j = i
            while j < n and lines[j].strip().startswith(">"):
                buf.append(lines[j].strip()[1:].strip())
                j += 1
            text = " ".join(buf)
            cls = "notice"
            mm = re.match(r"^\[!(warn|ok)\]\s*(.*)$", text)
            if mm:
                cls += " warn" if mm.group(1) == "warn" else " success"
                text = mm.group(2)
            out.append('<div class="%s">%s</div>' % (cls, inline(text)))
            i = j
            continue
        if re.match(r"^(- |\d+\. )", s):
            flush()
            ordered = bool(re.match(r"^\d+\. ", s))
            items = []
            j = i
            while j < n:
                raw = lines[j].rstrip("\n")
                t = raw.strip()
                if not t:
                    if j + 1 < n and re.match(r"^\s*(- |\d+\. )", lines[j + 1]):
                        j += 1
                        continue
                    break
                if raw.startswith(("   ", "\t")) and items and re.match(r"^(- |\d+\. )", t):
                    items[-1]["sub"].append(re.sub(r"^(- |\d+\. )", "", t))
                elif re.match(r"^(- |\d+\. )", t) and not raw.startswith(" "):
                    items.append({"text": re.sub(r"^(- |\d+\. )", "", t), "sub": []})
                elif items and raw.startswith(" "):
                    if items[-1]["sub"]:
                        items[-1]["sub"][-1] += " " + t
                    else:
                        items[-1]["text"] += " " + t
                else:
                    break
                j += 1
            if pending["checklist"] or all(it["text"].startswith("[ ]") for it in items):
                pending["checklist"] = False
                lab = []
                for k, it in enumerate(items):
                    lab.append('<label><input type="checkbox" data-check="%d"> <span>%s</span></label>'
                               % (k, inline(it["text"][3:].strip())))
                out.append('<div class="checklist" data-checklist>%s</div>' % "".join(lab))
            else:
                tag = "ol" if ordered else "ul"
                lis = []
                for it in items:
                    sub = ""
                    if it["sub"]:
                        sub = "<ul>%s</ul>" % "".join("<li>%s</li>" % inline(x) for x in it["sub"])
                    lis.append("<li>%s%s</li>" % (inline(it["text"]), sub))
                out.append("<%s>%s</%s>" % (tag, "".join(lis), tag))
            i = j
            continue
        para.append(line)
        i += 1
    flush()
    return "\n".join(out)


def split_pages(path):
    lines = path.read_text(encoding="utf-8").splitlines()
    group = {"name": "", "id": path.stem, "en": "", "pages": []}
    cur = None
    for line in lines:
        s = line.strip()
        if s.startswith("# ") and not group["name"]:
            group["name"] = s[2:].strip()
            continue
        d = DIRECTIVE.match(s)
        if d and d.group(1) == "group" and cur is None:
            gid, _, en = d.group(2).partition("·")
            group["id"], group["en"] = gid.strip(), en.strip()
            continue
        if s.startswith("## "):
            cur = {"name": s[3:].strip(), "lines": []}
            group["pages"].append(cur)
            continue
        if cur is not None:
            cur["lines"].append(line)
    return group


def build_page(page, base):
    lines = page["lines"]
    pid, desc, body = None, "", []
    shift = 1
    src = None
    for line in lines:
        d = DIRECTIVE.match(line.strip())
        if d and d.group(1) == "id":
            pid = d.group(2)
            continue
        if d and d.group(1) == "include":
            inc = (base / d.group(2)).resolve()
            sub = inc.read_text(encoding="utf-8").splitlines()
            sub = [x for x in sub if not x.startswith("# ")]
            body.extend(sub)
            shift = 0
            src = inc.relative_to(ROOT).as_posix()
            continue
        body.append(line)
    # 第一個（非提醒）說明框作為頁面摘要
    for k, line in enumerate(body):
        t = line.strip()
        if not t or DIRECTIVE.match(t):
            continue
        if t.startswith(">") and not t.startswith("> [!"):
            desc = t[1:].strip()
            body = body[:k] + body[k + 1:]
        break
    html_body = md_to_html(body, shift=shift)
    return {"id": pid, "name": page["name"], "desc": desc, "html": html_body, "src": src}


def main():
    docs = sorted((ROOT / "docs").glob("*.md"))
    groups = []
    for f in docs:
        g = split_pages(f)
        pages = [build_page(p, f.parent) for p in g["pages"]]
        for p in pages:
            p["src"] = p["src"] or "docs/" + f.name
        missing = [p["name"] for p in pages if not p["id"]]
        if missing:
            sys.exit("缺少 <!-- id: … -->：%s %s" % (f.name, missing))
        groups.append({"id": g["id"], "name": g["name"], "en": g["en"], "src": "docs/" + f.name,
                       "pages": pages})
    fmt = json.loads((ROOT / "format.json").read_text(encoding="utf-8"))
    data = {"groups": groups, "format": fmt}
    js = ("/* 由 scripts/build_portal.py 自 docs/*.md、AGENTS.md、format.json 產生，請勿手改。 */\n"
          "const GUIDE=%s;\n" % json.dumps(data, ensure_ascii=False, separators=(",", ":")))
    out = ROOT / "assets" / "content.js"
    out.write_text(js, encoding="utf-8")
    n = sum(len(g["pages"]) for g in groups)
    print("已產生 %s：%d 個群組、%d 頁、%d KB" % (out.relative_to(ROOT), len(groups), n, len(js.encode()) // 1024))


if __name__ == "__main__":
    main()
