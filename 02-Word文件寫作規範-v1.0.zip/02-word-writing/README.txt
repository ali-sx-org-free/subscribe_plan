Word 文件寫作規範 · 繁體中文 · v1.0

人：先開啟 index.html。無須安裝套件、登入或連上網路。
Agent：先讀 AGENTS.md；排版數值在 format.json，工具在 scripts/。
起始版型：templates/空白範本.docx；全部版面元素示範：templates/範例文件.docx。

交給 agent 的方式：index.html → 開始使用 → 交給 Agent（附可複製的交辦指令）。
執行腳本需要 Python 3.9 以上與 python-docx（pip install python-docx）。

預設為繁體字型（新細明體／微軟正黑體／標楷體＋Times New Roman）；
簡體文件把 format.json 的 profile 改為 zh-Hans。
本包只有寫作與排版規範、工具與中性範例；沒有業務資訊。
Portal 樣式（assets/portal.css、shell.js）與「01-視覺風格與Portal」相同。
