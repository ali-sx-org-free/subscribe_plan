Word 文件寫作規範 · 繁體中文 · v1.1（新增作圖流程，試用版）

人：先開啟 index.html。無須安裝套件、登入或連上網路。
Agent：可從 SKILL.md 進入；先讀 AGENTS.md；排版數值在 format.json，工具在 scripts/。
起始版型：templates/空白範本.docx；全部版面元素示範：templates/範例文件.docx。

交給 agent 的方式：index.html → 開始使用 → 交給 Agent（附可複製的交辦指令）。
執行腳本需要 Python 3.9 以上與 python-docx（pip install python-docx）。

預設為繁體字型（新細明體／微軟正黑體／標楷體＋Times New Roman）；
簡體文件把 format.json 的 profile 改為 zh-Hans。
本包只有寫作與排版規範、工具與中性範例；沒有業務資訊。
Portal 樣式（assets/portal.css、shell.js）與「01-視覺風格與Portal」相同。

新增：docs/6-作圖與模型適配.md，包含 ChatGPT／Claude／其他環境的能力分流、插畫生成與檢查、無生圖能力時的提示詞和腳本交接、Word 入稿驗收。
範本：templates/作圖任務範本.md、作圖交接範例.md、協作流程.mmd。
來源：原始 v1.0；原有 Python 工具、排版參數與 Word 範本未升級。
